package com.example.ptiles;

import static java.lang.Integer.parseInt;
import static java.lang.Integer.valueOf;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Timer;
import java.util.TimerTask;

public class level_didacticiel extends AppCompatActivity {

    TextView didact_text_main;





    Button startBtn;

    Button note1, note2, note3, note4, note11, note22, note33, note44, note111, note222, note333, note444;
    Button note1Img, note2Img, note3Img, note4Img, note11Img, note22Img, note33Img, note44Img, note111Img, note222Img, note333Img, note444Img;

    Button long1, long2, long3, long4;
    Button long1Img, long2Img, long3Img, long4Img;


    TextView score;
    ProgressBar progress_bar;
    LinearLayout layoutFail;
    RelativeLayout mainLayout2;
    ConstraintLayout mainLayout;


    private  MediaPlayer musique;

    int speedNote;
    int speedLong;
    float multiplier;

    int indice;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level);


        didact_text_main = findViewById(R.id.didact_text_main);





        startBtn = findViewById(R.id.startBtn);

        note1=findViewById(R.id.note1);
        note2=findViewById(R.id.note2);
        note3=findViewById(R.id.note3);
        note4=findViewById(R.id.note4);
        note11=findViewById(R.id.note11);
        note22=findViewById(R.id.note22);
        note33=findViewById(R.id.note33);
        note44=findViewById(R.id.note44);
        note111 = findViewById(R.id.note111);
        note222 = findViewById(R.id.note222);
        note333 = findViewById(R.id.note333);
        note444 = findViewById(R.id.note444);

        note1Img=findViewById(R.id.note1Img);
        note2Img=findViewById(R.id.note2Img);
        note3Img=findViewById(R.id.note3Img);
        note4Img=findViewById(R.id.note4Img);
        note11Img=findViewById(R.id.note11Img);
        note22Img=findViewById(R.id.note22Img);
        note33Img=findViewById(R.id.note33Img);
        note44Img=findViewById(R.id.note44Img);
        note111Img=findViewById(R.id.note111Img);
        note222Img=findViewById(R.id.note222Img);
        note333Img=findViewById(R.id.note333Img);
        note444Img=findViewById(R.id.note444Img);



        long1=findViewById(R.id.long1);
        long2=findViewById(R.id.long2);
        long3=findViewById(R.id.long3);
        long4=findViewById(R.id.long4);

        long1Img=findViewById(R.id.long1Img);
        long2Img=findViewById(R.id.long2Img);
        long3Img=findViewById(R.id.long3Img);
        long4Img=findViewById(R.id.long4Img);


        score = findViewById(R.id.score);
        progress_bar = findViewById(R.id.progress_bar);

        layoutFail = findViewById(R.id.layoutFail);
        mainLayout = findViewById(R.id.mainLayout);
        mainLayout2=findViewById(R.id.mainLayout2);


        speedNote=1000;
        speedLong = 1300;
        multiplier = 1.0f;


        progress_bar.setVisibility(ProgressBar.GONE);
        score.setVisibility(TextView.GONE);
        didact_text_main.setVisibility(TextView.VISIBLE);




    }





}



