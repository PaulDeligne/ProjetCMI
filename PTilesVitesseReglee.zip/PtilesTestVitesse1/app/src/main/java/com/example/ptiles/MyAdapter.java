package com.example.ptiles;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyAdapter extends ArrayAdapter<String>{

    String [] NomNiveau;
    int[] ImageNiveau;
    Context mContext;

    public MyAdapter(@NonNull Context context, String [] ListName, int[] ListImage) {
        super(context, R.layout.customlv);
        this.NomNiveau = ListName;
        this.ImageNiveau = ListImage;
        this.mContext = context;
    }

    @Override
    public int getCount() {
        return NomNiveau.length;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder mViewHolder = new ViewHolder();
        if (convertView == null) {
            LayoutInflater mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = mInflater.inflate(R.layout.customlv, parent, false);
            mViewHolder.mImage = (ImageView) convertView.findViewById(R.id.lvlimg);
            mViewHolder.mName = (TextView) convertView.findViewById(R.id.lvlname);
            convertView.setTag(mViewHolder);
        }else {mViewHolder = (ViewHolder) convertView.getTag();

        }
            mViewHolder.mImage.setImageResource(ImageNiveau[position]);
            mViewHolder.mName.setText(NomNiveau[position]);

        return convertView;
    }
    static class ViewHolder{
        ImageView mImage;
        TextView mName;
    }
}
