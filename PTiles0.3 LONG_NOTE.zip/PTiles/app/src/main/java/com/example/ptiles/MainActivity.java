package com.example.ptiles;

import static java.lang.Integer.parseInt;
import static java.lang.Integer.valueOf;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    Button startBtn;

    Button note1,note2,note3,note4,note11,note22,note33,note44;
    Button note1Img,note2Img,note3Img,note4Img,note11Img,note22Img,note33Img,note44Img;

    Button long1,long2,long3,long4;
    Button long1Img,long2Img,long3Img,long4Img;



    TextView score;
    LinearLayout layoutFail;




    AnimatorSet animSetXY1,animSetXY2,animSetXY3,animSetXY4,animSetXY11,animSetXY22,animSetXY33,animSetXY44,animSetXYL1,animSetXYL2,animSetXYL3,animSetXYL4;
    ObjectAnimator animX1,animY1,animX2,animY2,animX3,animY3,animX4,animY4,animX11,animY11,animX22,animY22,animX33,animY33,animX44,animY44,animXL1,animYL1,animXL2,animYL2,animXL3,animYL3,animXL4,animYL4;

    private static MediaPlayer snk;

    int indice=0;
    int[] tab = {1,4,2,3,2,2,1,4,3,2,2};

    int a=0;

    double longHoldTime1;
    double firstTouchTS = 0.;
    boolean longHold1;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startBtn = findViewById(R.id.startBtn);

        note1=findViewById(R.id.note1);
        note2=findViewById(R.id.note2);
        note3=findViewById(R.id.note3);
        note4=findViewById(R.id.note4);
        note11=findViewById(R.id.note11);
        note22=findViewById(R.id.note22);
        note33=findViewById(R.id.note33);
        note44=findViewById(R.id.note44);

        note1Img=findViewById(R.id.note1Img);
        note2Img=findViewById(R.id.note2Img);
        note3Img=findViewById(R.id.note3Img);
        note4Img=findViewById(R.id.note4Img);
        note11Img=findViewById(R.id.note11Img);
        note22Img=findViewById(R.id.note22Img);
        note33Img=findViewById(R.id.note33Img);
        note44Img=findViewById(R.id.note44Img);


        long1=findViewById(R.id.long1);
        long2=findViewById(R.id.long2);
        long3=findViewById(R.id.long3);
        long4=findViewById(R.id.long4);

        long1Img=findViewById(R.id.long1Img);
        long2Img=findViewById(R.id.long2Img);
        long3Img=findViewById(R.id.long3Img);
        long4Img=findViewById(R.id.long4Img);


        score = findViewById(R.id.score);

        layoutFail = findViewById(R.id.layoutFail);


        snk = MediaPlayer.create(MainActivity.this,R.raw.snk1);




        final boolean[] start = {false};


        //VERIFIER QUE LES NOTES SONT TOUTES CLIQUES
        final boolean[] note1cliqued = {false};
        final boolean[] note2cliqued = {false};
        final boolean[] note3cliqued = {false};
        final boolean[] note4cliqued = {false};
        final boolean[] note11cliqued = {false};
        final boolean[] note22cliqued = {false};
        final boolean[] note33cliqued = {false};
        final boolean[] note44cliqued = {false};
        final boolean[] long1cliqued = {false};
        final boolean[] long2cliqued = {false};
        final boolean[] long3cliqued = {false};
        final boolean[] long4cliqued = {false};

        //GET SCREEN SIZE

        DisplayMetrics metrics = this.getResources().getDisplayMetrics();
        int width = metrics.widthPixels; // LARGEUR
        int height = metrics.heightPixels; //LONGUEUR







        //SET ANIM POUR IMAGE ET BOUTON


        animX1 = ObjectAnimator.ofFloat(note1, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY1 = ObjectAnimator.ofFloat(note1Img, "y", -1000,height);
        animSetXY1 = new AnimatorSet();
        animSetXY1.playTogether(animX1, animY1);
        animSetXY1.setDuration(2500);
        animSetXY1.setInterpolator(new LinearInterpolator());


        animX2 = ObjectAnimator.ofFloat(note2, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY2 = ObjectAnimator.ofFloat(note2Img, "y", -1000,height);
        animSetXY2 = new AnimatorSet();
        animSetXY2.playTogether(animX2, animY2);
        animSetXY2.setDuration(2500);
        animSetXY2.setInterpolator(new LinearInterpolator());

        animX3 = ObjectAnimator.ofFloat(note3, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY3 = ObjectAnimator.ofFloat(note3Img, "y", -1000,height);
        animSetXY3 = new AnimatorSet();
        animSetXY3.playTogether(animX3, animY3);
        animSetXY3.setDuration(2500);
        animSetXY3.setInterpolator(new LinearInterpolator());


        animX4 = ObjectAnimator.ofFloat(note4, "y", -1200,height-200);//height = longueur ecran donc parcourstout l'ecran
        animY4 = ObjectAnimator.ofFloat(note4Img, "y", -1000,height);
        animSetXY4 = new AnimatorSet();
        animSetXY4.playTogether(animX4, animY4);
        animSetXY4.setDuration(2500);
        animSetXY4.setInterpolator(new LinearInterpolator());


        //DOUBLE

        animX11 = ObjectAnimator.ofFloat(note11, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY11 = ObjectAnimator.ofFloat(note11Img, "y", -1000,height);
        animSetXY11 = new AnimatorSet();
        animSetXY11.playTogether(animX11, animY11);
        animSetXY11.setDuration(2500);
        animSetXY11.setInterpolator(new LinearInterpolator());


        animX22 = ObjectAnimator.ofFloat(note22, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY22 = ObjectAnimator.ofFloat(note22Img, "y", -1000,height);
        animSetXY22 = new AnimatorSet();
        animSetXY22.playTogether(animX22, animY22);
        animSetXY22.setDuration(2500);
        animSetXY22.setInterpolator(new LinearInterpolator());

        animX33 = ObjectAnimator.ofFloat(note33, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY33 = ObjectAnimator.ofFloat(note33Img, "y", -1000,height);
        animSetXY33 = new AnimatorSet();
        animSetXY33.playTogether(animX33, animY33);
        animSetXY33.setDuration(2500);
        animSetXY33.setInterpolator(new LinearInterpolator());

        animX44 = ObjectAnimator.ofFloat(note44, "y", -1200,height-200);//height = longueur ecran donc parcours tout l'ecran
        animY44 = ObjectAnimator.ofFloat(note44Img, "y", -1000,height);
        animSetXY44 = new AnimatorSet();
        animSetXY44.playTogether(animX44, animY44);
        animSetXY44.setDuration(2500);
        animSetXY44.setInterpolator(new LinearInterpolator());


        //LONG

        animXL1 = ObjectAnimator.ofFloat(long1, "y", (-1*height)-200,height-200);//height = longueur ecran donc parcours tout l'ecran
        animYL1 = ObjectAnimator.ofFloat(long1Img, "y", -1*height,height);
        animSetXYL1 = new AnimatorSet();
        animSetXYL1.playTogether(animXL1, animYL1);
        animSetXYL1.setDuration(2500);
        animSetXYL1.setInterpolator(new LinearInterpolator());

        animXL2 = ObjectAnimator.ofFloat(long2, "y", (-1*height)-200,height-200);//height = longueur ecran donc parcours tout l'ecran
        animYL2 = ObjectAnimator.ofFloat(long2Img, "y", -1*height,height);
        animSetXYL2 = new AnimatorSet();
        animSetXYL2.playTogether(animXL2, animYL2);
        animSetXYL2.setDuration(2500);
        animSetXYL2.setInterpolator(new LinearInterpolator());

        animXL3 = ObjectAnimator.ofFloat(long3, "y", (-1*height)-200,height-200);//height = longueur ecran donc parcours tout l'ecran
        animYL3 = ObjectAnimator.ofFloat(long3Img, "y", -1*height,height);
        animSetXYL3 = new AnimatorSet();
        animSetXYL3.playTogether(animXL3, animYL3);
        animSetXYL3.setDuration(2500);
        animSetXYL3.setInterpolator(new LinearInterpolator());

        animXL4 = ObjectAnimator.ofFloat(long4, "y", (-1*height)-200,height-200);//height = longueur ecran donc parcours tout l'ecran
        animYL4 = ObjectAnimator.ofFloat(long4Img, "y", -1*height,height);
        animSetXYL4 = new AnimatorSet();
        animSetXYL4.playTogether(animXL4, animYL4);
        animSetXYL4.setDuration(2500);
        animSetXYL4.setInterpolator(new LinearInterpolator());







        animSetXY1.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {


            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                note1Img.setBackgroundColor(getColor(R.color.black));
                if(!note1cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                note1cliqued[0] = false;


                note1.setVisibility(Button.GONE);
                note1Img.setVisibility(Button.GONE);



            }

        });



        animSetXY2.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {


            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                note2Img.setBackgroundColor(getColor(R.color.black));

                if(!note2cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                note2cliqued[0] = false;


                note2.setVisibility(Button.GONE);
                note2Img.setVisibility(Button.GONE);

            }
        });



        animSetXY3.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {


            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                note3Img.setBackgroundColor(getColor(R.color.black));

                if(!note3cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu

                }
                note3cliqued[0] = false;


                note3.setVisibility(Button.GONE);
                note3Img.setVisibility(Button.GONE);

            }

        });




        animSetXY4.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {


            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                note4Img.setBackgroundColor(getColor(R.color.black));

                if(!note4cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu

                }
                note4cliqued[0] = false;

                note4.setVisibility(Button.GONE);
                note4Img.setVisibility(Button.GONE);

            }
        });

        //


        animSetXY11.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {


            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                note11Img.setBackgroundColor(getColor(R.color.black));
                if(!note11cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                note11cliqued[0] = false;


                note11.setVisibility(Button.GONE);
                note11Img.setVisibility(Button.GONE);



            }

        });



        animSetXY22.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {



            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                note22Img.setBackgroundColor(getColor(R.color.black));

                if(!note22cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                note22cliqued[0] = false;


                note22.setVisibility(Button.GONE);
                note22Img.setVisibility(Button.GONE);

            }
        });



        animSetXY33.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {


            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                note33Img.setBackgroundColor(getColor(R.color.black));

                if(!note33cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu

                }
                note33cliqued[0] = false;


                note33.setVisibility(Button.GONE);
                note33Img.setVisibility(Button.GONE);

            }

        });




        animSetXY44.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                note44Img.setBackgroundColor(getColor(R.color.black));

                if(!note44cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu

                }
                note44cliqued[0] = false;

                note44.setVisibility(Button.GONE);
                note44Img.setVisibility(Button.GONE);

            }
        });


        animSetXYL1.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                long1Img.setBackgroundColor(getColor(R.color.black));
                if(longHold1) {

                    longHoldTime1 = System.currentTimeMillis();
                    Toast.makeText(MainActivity.this,((longHoldTime1-firstTouchTS)/1000)+" seconds",Toast.LENGTH_LONG).show();
                }

                if(!long1cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                long1cliqued[0] = false;
                long1.setVisibility(Button.GONE);
                long1Img.setVisibility(Button.GONE);

            }
        });






        note1.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                if(!note1cliqued[0]) {
                    int intscore = parseInt(score.getText().toString()) + 100;
                    score.setText(String.valueOf(intscore));
                    note1Img.setBackgroundColor(getColor(R.color.grey));
                    note1cliqued[0] = true;
                }

            }
        });


        note2.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                if(!note2cliqued[0]) {
                    int intscore = parseInt(score.getText().toString()) + 100;
                    score.setText(String.valueOf(intscore));
                    note2Img.setBackgroundColor(getColor(R.color.grey));

                    note2cliqued[0] = true;
                }
            }
        });

        note3.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                if(!note3cliqued[0]) {
                    int intscore = parseInt(score.getText().toString()) + 100;
                    score.setText(String.valueOf(intscore));
                    note3Img.setBackgroundColor(getColor(R.color.grey));

                    note3cliqued[0] = true;
                }
            }
        });


        note4.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                if(!note4cliqued[0]) {
                    int intscore = parseInt(score.getText().toString()) + 100;
                    score.setText(String.valueOf(intscore));
                    note4Img.setBackgroundColor(getColor(R.color.grey));

                    note4cliqued[0] = true;
                }

            }
        });

        //


        note11.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                if(!note11cliqued[0]) {
                    int intscore = parseInt(score.getText().toString()) + 100;
                    score.setText(String.valueOf(intscore));
                    note11Img.setBackgroundColor(getColor(R.color.grey));
                    note11cliqued[0] = true;
                }

            }
        });


        note22.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                if(!note22cliqued[0]) {
                    int intscore = parseInt(score.getText().toString()) + 100;
                    score.setText(String.valueOf(intscore));
                    note22Img.setBackgroundColor(getColor(R.color.grey));

                    note22cliqued[0] = true;
                }
            }
        });

        note33.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                if(!note33cliqued[0]) {
                    int intscore = parseInt(score.getText().toString()) + 100;
                    score.setText(String.valueOf(intscore));
                    note33Img.setBackgroundColor(getColor(R.color.grey));

                    note33cliqued[0] = true;
                }
            }
        });


        note44.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                if(!note44cliqued[0]) {
                    int intscore = parseInt(score.getText().toString()) + 100;
                    score.setText(String.valueOf(intscore));
                    note44Img.setBackgroundColor(getColor(R.color.grey));

                    note44cliqued[0] = true;
                }

            }
        });



        //LONG

        long1.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                long1Img.setBackgroundColor(getColor(R.color.grey));
                long1cliqued[0] = true;


                if (event.getAction()==MotionEvent.ACTION_DOWN) {
                    longHold1=true;
                    firstTouchTS = System.currentTimeMillis();


                } else if (event.getAction()==MotionEvent.ACTION_UP) {

                    longHold1 = false;
                    if(animSetXYL1.isStarted()){
                        longHoldTime1 = System.currentTimeMillis();
                        Toast.makeText(MainActivity.this,((longHoldTime1-firstTouchTS)/1000)+" seconds",Toast.LENGTH_LONG).show();
                    }
                }
                return false;
            }
        });


        /*if(animSetXYL1.isStarted()) {

                    score.setText(String.valueOf(parseInt(score.getText().toString()) + 2));

                }*/





        layoutFail.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                if(start[0]) {
                    layoutFail.setBackgroundColor(getColor(R.color.red));
                }
            }
        });





        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                start[0] = true;
                startBtn.setVisibility(Button.GONE);
                snk.start();
                game();
            }
        });



    }








    public void game(){


        animSetXY1.setDuration(1000);
        animSetXY2.setDuration(1000);
        animSetXY3.setDuration(1000);
        animSetXY4.setDuration(1000);
        animSetXY11.setDuration(1000);
        animSetXY22.setDuration(1000);
        animSetXY33.setDuration(1000);
        animSetXY44.setDuration(1000);

        //note1Img.setVisibility(Button.VISIBLE);note1.setVisibility(Button.VISIBLE);animSetXY1.start();
        //note2Img.setVisibility(Button.VISIBLE);note2.setVisibility(Button.VISIBLE);animSetXY2.start();
        //note3Img.setVisibility(Button.VISIBLE);note3.setVisibility(Button.VISIBLE);animSetXY3.start();
        //note4Img.setVisibility(Button.VISIBLE);note4.setVisibility(Button.VISIBLE);animSetXY4.start();



        new CountDownTimer(3200, 1000) {

            @Override
            public void onTick(long millisUntilFinished) {
                // do something after 1s
            }

            @Override
            public void onFinish() {


                long1Img.setVisibility(Button.VISIBLE);
                long1.setVisibility(Button.VISIBLE);
                animSetXYL1.start();

                long4Img.setVisibility(Button.VISIBLE);
                long4.setVisibility(Button.VISIBLE);
                animSetXYL4.start();




                /*LEVEL

                new CountDownTimer(10000, 500) {

                    @Override
                    public void onTick(long millisUntilFinished) {


                        if(tab[indice]==1){
                            if(!animSetXY1.isStarted()) {
                                note1Img.setVisibility(Button.VISIBLE);
                                note1.setVisibility(Button.VISIBLE);
                                animSetXY1.start();
                            }
                            else{note11Img.setVisibility(Button.VISIBLE);
                                note11.setVisibility(Button.VISIBLE);
                                animSetXY11.start();}
                        }

                        else if(tab[indice]==2){
                            if(!animSetXY2.isStarted()) {
                                note2Img.setVisibility(Button.VISIBLE);
                                note2.setVisibility(Button.VISIBLE);
                                animSetXY2.start();


                            }
                            else{note22Img.setVisibility(Button.VISIBLE);
                                note22.setVisibility(Button.VISIBLE);
                                animSetXY22.start();

                            }
                        }

                        else if(tab[indice]==3){
                            if(!animSetXY3.isStarted()) {
                                note3Img.setVisibility(Button.VISIBLE);
                                note3.setVisibility(Button.VISIBLE);
                                animSetXY3.start();
                            }
                            else{note33Img.setVisibility(Button.VISIBLE);
                                note33.setVisibility(Button.VISIBLE);
                                animSetXY33.start();}
                        }

                        else if(tab[indice]==4){
                            if(!animSetXY4.isStarted()) {
                                note4Img.setVisibility(Button.VISIBLE);
                                note4.setVisibility(Button.VISIBLE);
                                animSetXY4.start();
                            }
                            else{note44Img.setVisibility(Button.VISIBLE);
                                note44.setVisibility(Button.VISIBLE);
                                animSetXY44.start();}
                        }

                        indice = indice + 1;
                        if(indice==11){indice=0;}

                    }

                    @Override
                    public void onFinish() {
                        a=a+1;

                        if(snk.isPlaying()) game();
                    }

                 }.start();



                 */



            }

        }.start();




    }

    void fall(){
        int v=1;
    }







    public int getRandomNumber(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }


    void loose(){
        int a =1;
    }
}



















































/*
new CountDownTimer(5000, 5000) {

            @Override
            public void onTick(long millisUntilFinished) {
                // do something after 1s
            }

            @Override
            public void onFinish() {


            }

        }.start();



        ANIMATOR TOGETHER

        ObjectAnimator animX = ObjectAnimator.ofFloat(myView, "x", 50f);
ObjectAnimator animY = ObjectAnimator.ofFloat(myView, "y", 100f);
AnimatorSet animSetXY = new AnimatorSet();
animSetXY.playTogether(animX, animY);
animSetXY.start();



PLAN : MEME CHOSE POUR LONG 2 3 4  , ajouter points en fonction des secondes, trouver animation de maintiens
 */
