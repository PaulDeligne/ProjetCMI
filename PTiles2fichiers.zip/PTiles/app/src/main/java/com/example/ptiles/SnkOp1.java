package com.example.ptiles;

import android.animation.AnimatorSet;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.RelativeLayout;

public class SnkOp1 extends MainActivity {


    public static void game(MediaPlayer snk, final float[] multiplier, final int[] speedNote, final int[] speedLong, RelativeLayout mainLayout2, ConstraintLayout mainLayout, Animation transition, final int[] indice,
                            int[] tab,
                            Button note1, Button note1Img, Button note11, Button note11Img, Button note111, Button note111Img, Button note2, Button note2Img, Button note22, Button note22Img, Button note222, Button note222Img,
                            Button note3, Button note3Img, Button note33, Button note33Img, Button note333, Button note333Img, Button note4, Button note4Img, Button note44, Button note44Img, Button note444, Button note444Img,
                            Button long1, Button long1Img, Button long2, Button long2Img, Button long3, Button long3Img, Button long4, Button long4Img,
                            AnimatorSet animSetXY1, AnimatorSet animSetXY2, AnimatorSet animSetXY3, AnimatorSet animSetXY4, AnimatorSet animSetXY11, AnimatorSet animSetXY22, AnimatorSet animSetXY33, AnimatorSet animSetXY44,
                            AnimatorSet animSetXY111, AnimatorSet animSetXY222, AnimatorSet animSetXY333, AnimatorSet animSetXY444, AnimatorSet animSetXYL1, AnimatorSet animSetXYL2, AnimatorSet animSetXYL3, AnimatorSet animSetXYL4){
        snk.start();

        new CountDownTimer((long)(3200/multiplier[0]), (long)(1000/multiplier[0])) {

            @Override
            public void onTick(long millisUntilFinished) {
                // do something after 1s
            }

            @Override
            public void onFinish() {


                new CountDownTimer((long)(10400/multiplier[0]), (long)(400/multiplier[0])) {

                    @Override
                    public void onTick(long millisUntilFinished) {

                        fall(tab,indice[0],note1,note1Img,note11,note11Img,note111,note111Img,note2,note2Img,note22,note22Img,note222,note222Img,
                                note3,note3Img,note33,note33Img,note333,note333Img,note4,note4Img,note44,note44Img,note444,note444Img,
                                long1,long1Img,long2,long2Img,long3,long3Img,long4,long4Img,
                                 animSetXY1,animSetXY2,animSetXY3,animSetXY4,animSetXY11,animSetXY22,animSetXY33,animSetXY44,
                                 animSetXY111,animSetXY222,animSetXY333,animSetXY444,animSetXYL1,animSetXYL2,animSetXYL3,animSetXYL4
                                );

                    }

                    @Override
                    public void onFinish() {


                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            public void run() {

                                mainLayout2.setBackgroundResource(R.drawable.degrad_yellow_pink);
                                mainLayout2.startAnimation(transition);
                                mainLayout.setBackgroundResource(R.drawable.degrad_yellow_pink);


                                new CountDownTimer((long)(22700/multiplier[0]), (long)(400/multiplier[0])) {

                                    @Override
                                    public void onTick(long millisUntilFinished) {

                                        fall(tab,indice[0],note1,note1Img,note11,note11Img,note111,note111Img,note2,note2Img,note22,note22Img,note222,note222Img,
                                                note3,note3Img,note33,note33Img,note333,note333Img,note4,note4Img,note44,note44Img,note444,note444Img,
                                                long1,long1Img,long2,long2Img,long3,long3Img,long4,long4Img,
                                                animSetXY1,animSetXY2,animSetXY3,animSetXY4,animSetXY11,animSetXY22,animSetXY33,animSetXY44,
                                                animSetXY111,animSetXY222,animSetXY333,animSetXY444,animSetXYL1,animSetXYL2,animSetXYL3,animSetXYL4
                                        );
                                    }

                                    @Override
                                    public void onFinish() {


                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            public void run() {
                                                new CountDownTimer((long)(3100/multiplier[0]), (long)(270/multiplier[0])) {

                                                    @Override
                                                    public void onTick(long millisUntilFinished) {

                                                        fall(tab,indice[0],note1,note1Img,note11,note11Img,note111,note111Img,note2,note2Img,note22,note22Img,note222,note222Img,
                                                                note3,note3Img,note33,note33Img,note333,note333Img,note4,note4Img,note44,note44Img,note444,note444Img,
                                                                long1,long1Img,long2,long2Img,long3,long3Img,long4,long4Img,
                                                                animSetXY1,animSetXY2,animSetXY3,animSetXY4,animSetXY11,animSetXY22,animSetXY33,animSetXY44,
                                                                animSetXY111,animSetXY222,animSetXY333,animSetXY444,animSetXYL1,animSetXYL2,animSetXYL3,animSetXYL4
                                                        );
                                                    }

                                                    @Override
                                                    public void onFinish() {

                                                        Handler handler = new Handler();
                                                        handler.postDelayed(new Runnable() {
                                                            public void run() {


                                                                Handler handler = new Handler(); //POUR l'animation
                                                                handler.postDelayed(new Runnable() {
                                                                    public void run() {
                                                                        mainLayout2.setBackgroundResource(R.drawable.degrad_red);
                                                                        mainLayout2.startAnimation(transition);
                                                                        mainLayout.setBackgroundResource(R.drawable.degrad_red);
                                                                    }
                                                                }, (long)(5300/multiplier[0]));



                                                                new CountDownTimer((long)(46000/multiplier[0]), (long)(400/multiplier[0])) {

                                                                    @Override
                                                                    public void onTick(long millisUntilFinished) {
                                                                        fall(tab,indice[0],note1,note1Img,note11,note11Img,note111,note111Img,note2,note2Img,note22,note22Img,note222,note222Img,
                                                                                note3,note3Img,note33,note33Img,note333,note333Img,note4,note4Img,note44,note44Img,note444,note444Img,
                                                                                long1,long1Img,long2,long2Img,long3,long3Img,long4,long4Img,
                                                                                animSetXY1,animSetXY2,animSetXY3,animSetXY4,animSetXY11,animSetXY22,animSetXY33,animSetXY44,
                                                                                animSetXY111,animSetXY222,animSetXY333,animSetXY444,animSetXYL1,animSetXYL2,animSetXYL3,animSetXYL4
                                                                        );
                                                                    }

                                                                    @Override
                                                                    public void onFinish() { // RECOMMENCER PLUS RAPIDEMENT

                                                                        Handler handler = new Handler();
                                                                        handler.postDelayed(new Runnable() {
                                                                            @RequiresApi(api = Build.VERSION_CODES.M)
                                                                            public void run() {

                                                                                multiplier[0] = multiplier[0] +(0.05f);
                                                                                snk.setPlaybackParams(snk.getPlaybackParams().setSpeed(multiplier[0]));

                                                                                speedNote[0]=(int)(speedNote[0]/multiplier[0]);
                                                                                speedLong[0]=(int)(speedLong[0]/multiplier[0]);

                                                                                animSetXY1.setDuration(speedNote[0]);
                                                                                animSetXY2.setDuration(speedNote[0]);
                                                                                animSetXY3.setDuration(speedNote[0]);
                                                                                animSetXY4.setDuration(speedNote[0]);

                                                                                animSetXY11.setDuration(speedNote[0]);
                                                                                animSetXY22.setDuration(speedNote[0]);
                                                                                animSetXY33.setDuration(speedNote[0]);
                                                                                animSetXY44.setDuration(speedNote[0]);

                                                                                animSetXY111.setDuration(speedNote[0]);
                                                                                animSetXY222.setDuration(speedNote[0]);
                                                                                animSetXY333.setDuration(speedNote[0]);
                                                                                animSetXY444.setDuration(speedNote[0]);

                                                                                animSetXYL1.setDuration(speedLong[0]);
                                                                                animSetXYL2.setDuration(speedLong[0]);
                                                                                animSetXYL3.setDuration(speedLong[0]);
                                                                                animSetXYL4.setDuration(speedLong[0]);

                                                                                indice[0]=0;

                                                                                mainLayout2.setBackgroundResource(R.drawable.degrad_pink_blue);
                                                                                mainLayout2.startAnimation(transition);
                                                                                mainLayout.setBackgroundResource(R.drawable.degrad_pink_blue);

                                                                                game( snk,multiplier,speedNote,speedLong,  mainLayout2,  mainLayout,  transition,indice,
                                                                                tab,
                                                                                 note1,  note1Img,  note11,  note11Img,  note111,  note111Img,  note2,  note2Img,  note22,  note22Img,  note222,  note222Img,
                                                                                         note3,  note3Img,  note33,  note33Img,  note333,  note333Img,  note4,  note4Img,  note44,  note44Img,  note444,  note444Img,
                                                                                         long1,  long1Img,  long2,  long2Img,  long3,  long3Img,  long4,  long4Img,
                                                                                         animSetXY1,  animSetXY2,  animSetXY3,  animSetXY4,  animSetXY11,  animSetXY22,  animSetXY33,  animSetXY44,
                                                                                         animSetXY111,  animSetXY222,  animSetXY333,  animSetXY444,  animSetXYL1,  animSetXYL2,  animSetXYL3,  animSetXYL4);


                                                                            }


                                                                        }, (long)(5000));

                                                                    }

                                                                }.start();


                                                            }
                                                        }, (long)(200/multiplier[0]));

                                                    }

                                                }.start();

                                            }
                                        }, (long)(300/multiplier[0]));
                                        //

                                    }

                                }.start();


                            }
                        }, (long)(2000/multiplier[0]));


                    }

                }.start();

            }

        }.start();




    }


}

// à fournir en paramètre de fall() : fall()


/* game :
game( snk,multiplier,speedNote,speedLong,  mainLayout2,  mainLayout,  transition,indice,
      tab,
      note1,  note1Img,  note11,  note11Img,  note111,  note111Img,  note2,  note2Img,  note22,  note22Img,  note222,  note222Img,
      note3,  note3Img,  note33,  note33Img,  note333,  note333Img,  note4,  note4Img,  note44,  note44Img,  note444,  note444Img,
      long1,  long1Img,  long2,  long2Img,  long3,  long3Img,  long4,  long4Img,
      animSetXY1,  animSetXY2,  animSetXY3,  animSetXY4,  animSetXY11,  animSetXY22,  animSetXY33,  animSetXY44,
      animSetXY111,  animSetXY222,  animSetXY333,  animSetXY444,  animSetXYL1,  animSetXYL2,  animSetXYL3,  animSetXYL4);


 */