package com.example.ptiles;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class listLvl extends AppCompatActivity {

     ListView lv;
     String[] ListName = {"Guren no yumiya","Gurenge","Rumbling","Tank"};
     int[] ListImage = {
             R.drawable.snk1_img,
             R.drawable.demon_slayer1_img,
             R.drawable.snk7_img,
             R.drawable.cowboy_bebop_img,
             R.drawable.mha9_img

     };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_lvl);


        lv = (ListView) findViewById(R.id.lv);
        MyAdapter myAdapter = new MyAdapter(listLvl.this, ListName, ListImage);
        lv.setAdapter(myAdapter);



        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent level = new Intent(listLvl.this,level.class);
                switch (ListName[i]) {
                    case "Guren no yumiya":
                        level.putExtra("niveau","snk1");
                        startActivity(level);
                        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                        break;

                    case "Gurenge":
                        level.putExtra("niveau","demon_slayer1");
                        startActivity(level);
                        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                        break;

                    case "Rumbling":
                        level.putExtra("niveau","snk7");
                        startActivity(level);
                        overridePendingTransition(R.anim.fadein, R.anim.fadeout);

                        break;
                    case "Tank":
                        level.putExtra("niveau","cowboy");
                        startActivity(level);
                        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                }

            }
        });



    }
}