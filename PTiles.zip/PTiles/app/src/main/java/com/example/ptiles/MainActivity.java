package com.example.ptiles;

import static java.lang.Integer.parseInt;
import static java.lang.Integer.valueOf;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.graphics.Rect;
import android.os.Build;
import android.os.CountDownTimer;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TouchDelegate;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button note1,note2,note3,note4;
    TextView score;
    ObjectAnimator animator1,animator2,animator3,animator4;

    RelativeLayout layoutFail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        note1=findViewById(R.id.note1);
        note2=findViewById(R.id.note2);
        note3=findViewById(R.id.note3);
        note4=findViewById(R.id.note4);

        score = findViewById(R.id.score);

        layoutFail = findViewById(R.id.layoutFail);



        final boolean[] n1Cliqued = {false};
        final boolean[] n2Cliqued = {false};

        final boolean[] n3Cliqued = {false};
        final boolean[] n4Cliqued = {false};








        //INCREASE HITBOX


        final View parent = (View) note1.getParent();  // button: the view you want to enlarge hit area
        parent.post( new Runnable() {
            public void run() {
                final Rect rect = new Rect();
                note1.getHitRect(rect);
                rect.top += 400;    // increase top hit area
                   // increase left hit area
                rect.bottom +=0; // increase bottom hit area
                  // increase right hit area
                parent.setTouchDelegate( new TouchDelegate( rect , note1));
            }
        });


        final View parent2 = (View) note2.getParent();  // button: the view you want to enlarge hit area
        parent2.post( new Runnable() {
            public void run() {
                final Rect rect = new Rect();
                note1.getHitRect(rect);
                rect.top += 400;    // increase top hit area
                   // increase left hit area
                rect.bottom +=0; // increase bottom hit area
                  // increase right hit area
                parent2.setTouchDelegate( new TouchDelegate( rect , note2));
            }
        });


        final View parent3 = (View) note3.getParent();  // button: the view you want to enlarge hit area
        parent3.post( new Runnable() {
            public void run() {
                final Rect rect = new Rect();
                note3.getHitRect(rect);
                rect.top += 400;    // increase top hit area
                   // increase left hit area
                rect.bottom +=0; // increase bottom hit area
                  // increase right hit area
                parent3.setTouchDelegate( new TouchDelegate( rect , note3));
            }
        });


        final View parent4 = (View) note4.getParent();  // button: the view you want to enlarge hit area
        parent4.post( new Runnable() {
            public void run() {
                final Rect rect = new Rect();
                note1.getHitRect(rect);
                rect.top += 400;    // increase top hit area
                   // increase left hit area
                rect.bottom +=0; // increase bottom hit area
                  // increase right hit area
                parent4.setTouchDelegate( new TouchDelegate( rect , note4));
            }
        });







        animator1=ObjectAnimator.ofFloat(note1,"y",-1500,2000);
        animator1.setDuration(2000);

        animator1.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                note1.setBackgroundColor(getColor(R.color.black));
                if(!n1Cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red));
                }
                n1Cliqued[0]=false;

            }

            @Override
            public void onAnimationCancel(Animator animator) {

            }

            @Override
            public void onAnimationRepeat(Animator animator) {

            }
        });

        animator2=ObjectAnimator.ofFloat(note2,"y",-1500,2000);
        animator2.setDuration(2000);


        animator2.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                note2.setBackgroundColor(getColor(R.color.black));

                if(!n2Cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red));
                }
                n2Cliqued[0]=false;

            }

            @Override
            public void onAnimationCancel(Animator animator) {

            }

            @Override
            public void onAnimationRepeat(Animator animator) {

            }
        });

        animator3=ObjectAnimator.ofFloat(note3,"y",-1500,2000);
        animator3.setDuration(2000);

        animator3.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                note3.setBackgroundColor(getColor(R.color.black));

                if(!n3Cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red));
                }
                n3Cliqued[0]=false;
            }

            @Override
            public void onAnimationCancel(Animator animator) {

            }

            @Override
            public void onAnimationRepeat(Animator animator) {

            }
        });


        animator4=ObjectAnimator.ofFloat(note4,"y",-1500,2000);
        animator4.setDuration(2000);


        animator4.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                note4.setBackgroundColor(getColor(R.color.black));

                if(!n4Cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red));
                }
                n4Cliqued[0]=false;

            }

            @Override
            public void onAnimationCancel(Animator animator) {

            }

            @Override
            public void onAnimationRepeat(Animator animator) {

            }
        });


        note1.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                int intscore= parseInt(score.getText().toString())+1;
                score.setText(String.valueOf(intscore));
                note1.setBackgroundColor(getColor(R.color.grey));
                n1Cliqued[0] = true;

            }
        });

        note2.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                int intscore= parseInt(score.getText().toString())+1;
                score.setText(String.valueOf(intscore));
                note2.setBackgroundColor(getColor(R.color.grey));
                n2Cliqued[0] = true;

            }
        });


        note3.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                int intscore= parseInt(score.getText().toString())+1;
                score.setText(String.valueOf(intscore));
                note3.setBackgroundColor(getColor(R.color.grey));
                n3Cliqued[0] = true;

            }
        });


        note4.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                int intscore= parseInt(score.getText().toString())+1;
                score.setText(String.valueOf(intscore));
                note4.setBackgroundColor(getColor(R.color.grey));
                n4Cliqued[0] = true;


            }
        });

        layoutFail.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                layoutFail.setBackgroundColor(getColor(R.color.red));
            }
        });


        game();

    }

    void game(){



        new CountDownTimer(5000, 1000) {

            @Override
            public void onTick(long millisUntilFinished) {
                // do something after 1s
            }

            @Override
            public void onFinish() {

                fall();

            }

        }.start();


    }

    void fall(){
        final int[] i = {getRandomNumber(1, 5)};
        new CountDownTimer(15000, 2100) {

            @Override
            public void onTick(long millisUntilFinished) {
                if(i[0] ==1){note1.setVisibility(Button.VISIBLE);animator1.start();}
                else if(i[0] ==2){note2.setVisibility(Button.VISIBLE);animator2.start();}
                else if(i[0] ==3){note3.setVisibility(Button.VISIBLE);animator3.start();}
                else if(i[0] ==4){note4.setVisibility(Button.VISIBLE);animator4.start();}
                i[0] =getRandomNumber(1,5);

            }

            @Override
            public void onFinish() {

                fall();

            }

        }.start();

    }

    public int getRandomNumber(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }
}

/*

new CountDownTimer(5000, 5000) {

            @Override
            public void onTick(long millisUntilFinished) {
                // do something after 1s
            }

            @Override
            public void onFinish() {


            }

        }.start();



        INIMATOR TOGETHER

        ObjectAnimator animX = ObjectAnimator.ofFloat(myView, "x", 50f);
ObjectAnimator animY = ObjectAnimator.ofFloat(myView, "y", 100f);
AnimatorSet animSetXY = new AnimatorSet();
animSetXY.playTogether(animX, animY);
animSetXY.start();
 */