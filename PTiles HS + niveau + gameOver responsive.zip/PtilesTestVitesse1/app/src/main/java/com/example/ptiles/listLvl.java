package com.example.ptiles;

import java.util.Arrays;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Switch;

public class listLvl extends AppCompatActivity {
    RelativeLayout paraLayout;
    Button param;
    Button retour;
    Switch vibra;
    Switch repet;
    Button layout_para;



    ListView lv;
    String[] difficulte = {"Facile","Facile","Moyen","Moyen","Difficile","Facile","Facile"};
    String[] ListName = {"Didacticiel","Guren no yumiya", "Gurenge","Merry Go Round", "Rumbling", "Tank!", "A Cruel Angel's Thesis"};
    String[] nameHs={"","hs_snk1","hs_demon_slayer1","hs_mha9","hs_snk7","hs_cowboy","hs_evangelion"};
    int tailleLv = ListName.length;
    String[] hs = new String[tailleLv];

    Boolean vibraB,repetB;



    int[] ListImage = {
            R.drawable.tuto_img,
            R.drawable.snk1_img,
            R.drawable.demon_slayer1_img,
            R.drawable.mha9_img,
            R.drawable.snk7_img,
            R.drawable.cowboy_bebop_img,
            R.drawable.evangelion_img


    };

    Boolean ouvert;
    Boolean musiquePlaying;
    MediaPlayer musique_menu,musique_transition;
    Boolean pause = false;
    int length;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_lvl);
        paraLayout = findViewById(R.id.paraLayout);
        param = findViewById(R.id.param);
        retour= findViewById(R.id.retour);
        vibra = findViewById(R.id.vibra);
        repet=findViewById(R.id.repet);

        layout_para=findViewById(R.id.layout_para);

        musiquePlaying = false;
        ouvert=false;
        pause = true;


        SharedPreferences sharedPreferences = getSharedPreferences("sharedVariables",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        for(int i = 0;i<tailleLv;i++){
            hs[i] = sharedPreferences.getString(nameHs[i],"");  //remplissage de la liste des high scores

        }


        vibra.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                editor.putBoolean("vibraB",vibra.isChecked());
                editor.apply();
            }
        });
        repet.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                editor.putBoolean("repetB",repet.isChecked());
                editor.apply();
            }
        });

        vibraB =sharedPreferences.getBoolean("vibraB",true);
        repetB = sharedPreferences.getBoolean("repetB",false);

        vibra.setChecked(vibraB);
        repet.setChecked(repetB);


        lv = (ListView) findViewById(R.id.lv);
        MyAdapter myAdapter = new MyAdapter(listLvl.this, ListName,difficulte, ListImage,hs);
        lv.setAdapter(myAdapter);

        musique_transition = MediaPlayer.create(listLvl.this,R.raw.effet_transition);

        musique_menu = MediaPlayer.create(listLvl.this, R.raw.musique_menu);
        musique_menu.setLooping(true);
        if(!musiquePlaying) {
            musique_menu.start();
            musiquePlaying = true;
        }

        param.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                paraLayout.setVisibility(RelativeLayout.VISIBLE);
                layout_para.setVisibility(Button.VISIBLE);

                ouvert=true;




            }

        });

        paraLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        layout_para.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                paraLayout.setVisibility(RelativeLayout.GONE);
                layout_para.setVisibility(Button.GONE);
                ouvert=false;




            }

        });
        musique_menu.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                if (musiquePlaying) musique_menu.start();
            }
        });


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(ouvert==false){

                    Intent level = new Intent(listLvl.this, level.class);
                    level.putExtra("vibraB", vibraB);
                    level.putExtra("repetB", repetB);
                    musique_transition.start();
                    switch (ListName[i]) {
                        case "Didacticiel":

                            Intent didacticiel = new Intent(listLvl.this, level_didacticiel.class);

                            didacticiel.putExtra("length_musique",musique_menu.getCurrentPosition()+1000);
                            startActivity(didacticiel);
                            overridePendingTransition(R.anim.fadein, R.anim.fadeout);

                            break;
                        case "A Cruel Angel's Thesis":
                            level.putExtra("niveau", "evangelion");

                            startActivity(level);
                            overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                            break;

                        case "Guren no yumiya":
                            level.putExtra("niveau", "snk1");

                            startActivity(level);
                            overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                            break;

                        case "Gurenge":
                            level.putExtra("niveau", "demon_slayer1");

                            startActivity(level);
                            overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                            break;

                        case "Make my story":

                            level.putExtra("niveau","mha5");

                            startActivity(level);
                            overridePendingTransition(R.anim.fadein, R.anim.fadeout);

                            break;

                        case "Merry Go Round":
                            level.putExtra("niveau", "mha9");

                            startActivity(level);
                            overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                            break;

                        case "Rumbling":
                            level.putExtra("niveau", "snk7");

                            startActivity(level);
                            overridePendingTransition(R.anim.fadein, R.anim.fadeout);

                            break;

                        case "Tank!":

                            level.putExtra("niveau","cowboy");

                            startActivity(level);
                            overridePendingTransition(R.anim.fadein, R.anim.fadeout);

                            break;
                    }

                }
            }
        });


    }
    @Override
    protected void onPause() {
        super.onPause();

        musique_menu.pause();
        length = musique_menu.getCurrentPosition();

    }

    @Override
    protected void onResume() {

        super.onResume();

        if (pause) { //Si pause est vrai on est bien dans le onResume

            musique_menu.seekTo(length);
            musique_menu.start();

        }
    }
}