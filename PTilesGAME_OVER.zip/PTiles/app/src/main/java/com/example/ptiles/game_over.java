package com.example.ptiles;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class game_over extends AppCompatActivity {

    RelativeLayout over_Layout,over_Layout_score,over_Layout_iconLevel,over_Layout_score_max,over_Layout_menu,over_Layout_replay;
    TextView over_score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        over_Layout = findViewById(R.id.over_Layout);
        over_Layout_score = findViewById(R.id.over_Layout_score);
        over_Layout_iconLevel = findViewById(R.id.over_Layout_iconLevel);
        over_Layout_score_max = findViewById(R.id.over_Layout_score_max);
        over_Layout_menu = findViewById(R.id.over_Layout_menu);
        over_Layout_replay = findViewById(R.id.over_Layout_replay);

        over_score = findViewById(R.id.over_score);


        //RECUPERATION INTENT

        Intent i = getIntent();
        String score;
        score = i.getStringExtra("score");

        over_score.setText(score);


    }
}