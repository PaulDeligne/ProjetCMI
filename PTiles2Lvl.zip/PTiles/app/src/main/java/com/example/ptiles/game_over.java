package com.example.ptiles;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import de.hdodenhof.circleimageview.CircleImageView;

public class game_over extends AppCompatActivity {

    RelativeLayout over_Layout,over_Layout_score,over_Layout_score_max;
    CircleImageView over_circle_image;
    ImageView over_img_menu,over_img_rejouer;
    TextView over_score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        over_circle_image = findViewById(R.id.over_circle_image);

        over_Layout = findViewById(R.id.over_Layout);
        over_Layout_score = findViewById(R.id.over_Layout_score);
        over_Layout_score_max = findViewById(R.id.over_Layout_score_max);
        over_img_menu = findViewById(R.id.over_img_menu);
        over_img_rejouer = findViewById(R.id.over_img_rejouer);

        over_score = findViewById(R.id.over_score);


        //RECUPERATION INTENT

        Intent i = getIntent();
        String score;
        score = i.getStringExtra("score");

        over_score.setText(score);


        over_img_rejouer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent j = new Intent(game_over.this, MainActivity.class);
                startActivity(j);
                overridePendingTransition(R.anim.fadein, R.anim.fadeout);
            }
        });


    }
}