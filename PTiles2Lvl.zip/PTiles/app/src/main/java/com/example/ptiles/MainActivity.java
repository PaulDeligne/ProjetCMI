package com.example.ptiles;

import static java.lang.Integer.parseInt;
import static java.lang.Integer.valueOf;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    Button startBtn;
    Button startBtn2;

    Button note1,note2,note3,note4,note11,note22,note33,note44,note111,note222,note333,note444;
    Button note1Img,note2Img,note3Img,note4Img,note11Img,note22Img,note33Img,note44Img,note111Img,note222Img,note333Img,note444Img;

    Button long1,long2,long3,long4;
    Button long1Img,long2Img,long3Img,long4Img;



    TextView score;
    LinearLayout layoutFail;
    RelativeLayout mainLayout2;
    ConstraintLayout mainLayout;




    AnimatorSet animSetXY1,animSetXY2,animSetXY3,animSetXY4,
            animSetXY11,animSetXY22,animSetXY33,animSetXY44,
            animSetXY111,animSetXY222,animSetXY333,animSetXY444,
            animSetXYL1,animSetXYL2,animSetXYL3,animSetXYL4;


    ObjectAnimator animX1,animY1,animX2,animY2,animX3,animY3,animX4,animY4,
            animX11,animY11,animX22,animY22,animX33,animY33,animX44,animY44,
            animX111,animY111,animX222,animY222,animX333,animY333,animX444,animY444,
            animXL1,animYL1,animXL2,animYL2,animXL3,animYL3,animXL4,animYL4;


    private  MediaPlayer musique;

    int speedNote;
    int speedLong;
    float multiplier;

    int indice;
    int[] snk1_tab = {1,4,2,3,2,2,1,4,3,2,2,1,4,2,3,2,4,3,4,1,3,2,3,4,22  //[25] = coup 1
            ,4,3,2,1,2,1,2,1,4,3,4,3,11,3,4,3,4,2,1,4,2,1,3,44,1,2,3,4,2,2,4,3,1,2,2,3,1,3,1,4,2,11,3,3,4,2,1,4,3,1,3,2,4,3,2,4,2,3//57/58
            ,1,1,1,3,3,2,2,2,4,4,4 //12
            ,1,2,3,4,4,3,2,1,4,1,3,2,4,5,4,3,1,33,1,1,2,1,4,1,1,2,3,3,4,2,1,3,4,3,2,1,3,11,4,3,2,1,2,3,1,2,2,1,4,33,1,4,2,3,1,22,4,2,1,2,3,4,4,3,2,1,4,1,3,2,4,5,4,3,1,33,1,1,2,1,4,1,1,2,3,3,4,2,1,3,4,3,2,1,3,11,4,3,2,1,2,3,1,22,4,1,4,3,1,4,2,33 //120
    };

    int[] tab_demonSlayer1 = {1,2,1, //0
            2,3,2,//3
            3,4,3,4,22,9999,9999,9999,2,//6
            1,2,3,//15
            3,2,1,//18
            4,4,22,9999,//21
            14//25
            ,1,3,2,4,13,2,4,3,2,14,2,3,2,1,24,1,2,3,44,9999,//26
            1,2,4,2,33,1,1,//46
            13,24,13,24,13,//53
            1,4,22,9999,13,2,3,24,1,2,33,9999//58
            ,1,3,2,4,13,2,4,3,2,14,2,3,2,1,24,1,2,3,44,9999,2,2,1,22,9999,2,1,//70
            13,24,13,24,13,//97
            1,2,3,2,3,//102
            13,24,13,24,13,//107
            1,2,3,4,1,2,4,3,2,11,9999,4,3,2,2,3,1,2,3,2,3,14,//112
            1,2,1,//134
            2,3,2,//137
            3,4,3,4,22,9999,9999,9999,2,//140
            4,3,2,//149
            2,3,1,//152
            2,2,33,9999//155
            ,1,3,2,4,13,2,4,3,2,14,2,3,2,1,24,1,2,3,44,9999, // =20 notes
            1,2,3,4,1,2,4,3,2,11,9999,4,3,2,2,3,1,2,3,2,3,14, //=22 notes
            1,3,2,4,13,2,4,3,2,14,2,3,2,1,24,1,2,3,44,9999,2,2,1,22,9999,2,1 // =27 notes
    };

    //LONG VAR
    final double[] firstTouch1 = {0.},firstTouch2 = {0.},firstTouch3 = {0.},firstTouch4 = {0.};
    final boolean[] longHold1={false},longHold2={false},longHold3={false},longHold4={false};



    boolean arret;

    Animation transition;
    Vibrator vibrator;


    //VERIFIER QUE LES NOTES SONT TOUTES CLIQUES, type = tableau à 1 element de boulean -> pour que les valeurs puisse être modifiés à l'interieur des fonctions.
    final Boolean[] note1cliqued={false},note2cliqued={false},note3cliqued={false},note4cliqued={false},note11cliqued={false},note22cliqued={false},note33cliqued={false},note44cliqued={false},
            note111cliqued={false},note222cliqued={false},note333cliqued={false},note444cliqued={false},long1cliqued={false},long2cliqued={false},long3cliqued={false},long4cliqued={false};




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startBtn = findViewById(R.id.startBtn);
        startBtn2 = findViewById(R.id.startBtn2);

        note1=findViewById(R.id.note1);
        note2=findViewById(R.id.note2);
        note3=findViewById(R.id.note3);
        note4=findViewById(R.id.note4);
        note11=findViewById(R.id.note11);
        note22=findViewById(R.id.note22);
        note33=findViewById(R.id.note33);
        note44=findViewById(R.id.note44);
        note111 = findViewById(R.id.note111);
        note222 = findViewById(R.id.note222);
        note333 = findViewById(R.id.note333);
        note444 = findViewById(R.id.note444);

        note1Img=findViewById(R.id.note1Img);
        note2Img=findViewById(R.id.note2Img);
        note3Img=findViewById(R.id.note3Img);
        note4Img=findViewById(R.id.note4Img);
        note11Img=findViewById(R.id.note11Img);
        note22Img=findViewById(R.id.note22Img);
        note33Img=findViewById(R.id.note33Img);
        note44Img=findViewById(R.id.note44Img);
        note111Img=findViewById(R.id.note111Img);
        note222Img=findViewById(R.id.note222Img);
        note333Img=findViewById(R.id.note333Img);
        note444Img=findViewById(R.id.note444Img);



        long1=findViewById(R.id.long1);
        long2=findViewById(R.id.long2);
        long3=findViewById(R.id.long3);
        long4=findViewById(R.id.long4);

        long1Img=findViewById(R.id.long1Img);
        long2Img=findViewById(R.id.long2Img);
        long3Img=findViewById(R.id.long3Img);
        long4Img=findViewById(R.id.long4Img);


        score = findViewById(R.id.score);

        layoutFail = findViewById(R.id.layoutFail);
        mainLayout = findViewById(R.id.mainLayout);
        mainLayout2=findViewById(R.id.mainLayout2);


        speedNote=1000;
        speedLong = 1300;
        multiplier = 1.0f;

        arret = false;


        final boolean[] start = {false};


        //GET SCREEN SIZE

        DisplayMetrics metrics = this.getResources().getDisplayMetrics();
        int height = metrics.heightPixels; //LONGUEUR



        transition = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blinking_animation150);

        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);




        //SET ANIM POUR IMAGE ET BOUTON


        animX1 = ObjectAnimator.ofFloat(note1, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY1 = ObjectAnimator.ofFloat(note1Img, "y", -1000,height);
        animSetXY1 = new AnimatorSet();
        animSetXY1.playTogether(animX1, animY1);
        animSetXY1.setDuration(2500);
        animSetXY1.setInterpolator(new LinearInterpolator());


        animX2 = ObjectAnimator.ofFloat(note2, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY2 = ObjectAnimator.ofFloat(note2Img, "y", -1000,height);
        animSetXY2 = new AnimatorSet();
        animSetXY2.playTogether(animX2, animY2);
        animSetXY2.setInterpolator(new LinearInterpolator());

        animX3 = ObjectAnimator.ofFloat(note3, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY3 = ObjectAnimator.ofFloat(note3Img, "y", -1000,height);
        animSetXY3 = new AnimatorSet();
        animSetXY3.playTogether(animX3, animY3);
        animSetXY3.setInterpolator(new LinearInterpolator());


        animX4 = ObjectAnimator.ofFloat(note4, "y", -1200,height-200);//height = longueur ecran donc parcourstout l'ecran
        animY4 = ObjectAnimator.ofFloat(note4Img, "y", -1000,height);
        animSetXY4 = new AnimatorSet();
        animSetXY4.playTogether(animX4, animY4);
        animSetXY4.setInterpolator(new LinearInterpolator());


        //SECONDES NOTES PAR LIGNES

        animX11 = ObjectAnimator.ofFloat(note11, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY11 = ObjectAnimator.ofFloat(note11Img, "y", -1000,height);
        animSetXY11 = new AnimatorSet();
        animSetXY11.playTogether(animX11, animY11);
        animSetXY11.setInterpolator(new LinearInterpolator());


        animX22 = ObjectAnimator.ofFloat(note22, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY22 = ObjectAnimator.ofFloat(note22Img, "y", -1000,height);
        animSetXY22 = new AnimatorSet();
        animSetXY22.playTogether(animX22, animY22);
        animSetXY22.setInterpolator(new LinearInterpolator());

        animX33 = ObjectAnimator.ofFloat(note33, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY33 = ObjectAnimator.ofFloat(note33Img, "y", -1000,height);
        animSetXY33 = new AnimatorSet();
        animSetXY33.playTogether(animX33, animY33);
        animSetXY33.setInterpolator(new LinearInterpolator());

        animX44 = ObjectAnimator.ofFloat(note44, "y", -1200,height-200);//height = longueur ecran donc parcours tout l'ecran
        animY44 = ObjectAnimator.ofFloat(note44Img, "y", -1000,height);
        animSetXY44 = new AnimatorSet();
        animSetXY44.playTogether(animX44, animY44);
        animSetXY44.setInterpolator(new LinearInterpolator());


        //TROISIEME PAR LIGNES

        animX111 = ObjectAnimator.ofFloat(note111, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY111 = ObjectAnimator.ofFloat(note111Img, "y", -1000,height);
        animSetXY111 = new AnimatorSet();
        animSetXY111.playTogether(animX111, animY111);
        animSetXY111.setInterpolator(new LinearInterpolator());


        animX222 = ObjectAnimator.ofFloat(note222, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY222 = ObjectAnimator.ofFloat(note222Img, "y", -1000,height);
        animSetXY222 = new AnimatorSet();
        animSetXY222.playTogether(animX222, animY222);
        animSetXY222.setInterpolator(new LinearInterpolator());

        animX333 = ObjectAnimator.ofFloat(note333, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY333 = ObjectAnimator.ofFloat(note333Img, "y", -1000,height);
        animSetXY333 = new AnimatorSet();
        animSetXY333.playTogether(animX333, animY333);
        animSetXY333.setInterpolator(new LinearInterpolator());

        animX444 = ObjectAnimator.ofFloat(note444, "y", -1200,height-200);//height = longueur ecran donc parcours tout l'ecran
        animY444 = ObjectAnimator.ofFloat(note444Img, "y", -1000,height);
        animSetXY444 = new AnimatorSet();
        animSetXY444.playTogether(animX444, animY444);
        animSetXY444.setInterpolator(new LinearInterpolator());


        //LONGUES

        animXL1 = ObjectAnimator.ofFloat(long1, "y", (-1*height),height);//height = longueur ecran donc parcours tout l'ecran
        animYL1 = ObjectAnimator.ofFloat(long1Img, "y", -1*height,height);
        animSetXYL1 = new AnimatorSet();
        animSetXYL1.playTogether(animXL1, animYL1);
        animSetXYL1.setInterpolator(new LinearInterpolator());

        animXL2 = ObjectAnimator.ofFloat(long2, "y", (-1*height),height);//height = longueur ecran donc parcours tout l'ecran
        animYL2 = ObjectAnimator.ofFloat(long2Img, "y", -1*height,height);
        animSetXYL2 = new AnimatorSet();
        animSetXYL2.playTogether(animXL2, animYL2);
        animSetXYL2.setInterpolator(new LinearInterpolator());

        animXL3 = ObjectAnimator.ofFloat(long3, "y", (-1*height),height);//height = longueur ecran donc parcours tout l'ecran
        animYL3 = ObjectAnimator.ofFloat(long3Img, "y", -1*height,height);
        animSetXYL3 = new AnimatorSet();
        animSetXYL3.playTogether(animXL3, animYL3);
        animSetXYL3.setInterpolator(new LinearInterpolator());

        animXL4 = ObjectAnimator.ofFloat(long4, "y", (-1*height),height);//height = longueur ecran donc parcours tout l'ecran
        animYL4 = ObjectAnimator.ofFloat(long4Img, "y", -1*height,height);
        animSetXYL4 = new AnimatorSet();
        animSetXYL4.playTogether(animXL4, animYL4);
        animSetXYL4.setInterpolator(new LinearInterpolator());







        animSetXY1.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                note1Img.setAlpha(1.0f);;

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {

                restartAnimNote(note1,note1Img,note1cliqued);
            }

        });



        animSetXY2.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

                note2Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimNote(note2,note2Img,note2cliqued);

            }
        });



        animSetXY3.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

                note3Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimNote(note3,note3Img,note3cliqued);

            }

        });




        animSetXY4.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                note4Img.setAlpha(1.0f);

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimNote(note4,note4Img,note4cliqued);

            }
        });

        //


        animSetXY11.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                note11Img.setAlpha(1.0f);

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimNote(note11,note11Img,note11cliqued);
            }

        });



        animSetXY22.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

                note22Img.setAlpha(1.0f);

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimNote(note22,note22Img,note22cliqued);
            }
        });



        animSetXY33.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

                note33Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimNote(note33,note33Img,note33cliqued);
            }

        });




        animSetXY44.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                note44Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimNote(note44,note44Img,note44cliqued);
            }
        });
        //TROISIEME


        animSetXY111.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

                note111Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimNote(note111,note111Img,note111cliqued);
            }

        });



        animSetXY222.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {


                note222Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimNote(note222,note222Img,note222cliqued);
            }
        });



        animSetXY333.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                note333Img.setAlpha(1.0f);

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimNote(note333,note333Img,note333cliqued);
            }

        });




        animSetXY444.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                note444Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimNote(note444,note444Img,note444cliqued);
            }
        });


        //LONG

        animSetXYL1.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                long1Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {

                restartAnimLong(long1,long1Img,longHold1[0],long1cliqued,firstTouch1[0]);

            }
        });


        animSetXYL2.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                long2Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimLong(long2,long2Img,longHold2[0],long2cliqued,firstTouch2[0]);

            }
        });


        animSetXYL3.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                long3Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimLong(long3,long3Img,longHold3[0],long3cliqued,firstTouch3[0]);

            }
        });


        animSetXYL4.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

                long4Img.setAlpha(1.0f);

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                restartAnimLong(long4,long4Img,longHold4[0],long4cliqued,firstTouch4[0]);
            }
        });



        note1.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    noteTouch(note1Img,note1cliqued);
                }
                return false;
            }
        });


        note2.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    noteTouch(note2Img,note2cliqued);
                }
                return false;
            }
        });

        note3.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    noteTouch(note3Img,note3cliqued);
                }
                return false;
            }
        });

        note4.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    noteTouch(note4Img,note4cliqued);
                }
                return false;
            }
        });

        //SECOND

        note11.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    noteTouch(note11Img,note11cliqued);
                }
                return false;
            }
        });

        note22.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    noteTouch(note22Img,note22cliqued);
                }
                return false;
            }
        });

        note33.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    noteTouch(note33Img,note33cliqued);
                }
                return false;
            }
        });

        note44.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    noteTouch(note44Img,note44cliqued);
                }
                return false;
            }
        });

        //TROISIEME

        note111.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    noteTouch(note111Img,note111cliqued);
                }
                return false;
            }
        });

        note222.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    noteTouch(note222Img,note222cliqued);
                }
                return false;
            }
        });

        note333.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    noteTouch(note333Img,note333cliqued);
                }
                return false;
            }
        });

        note444.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    noteTouch(note444Img,note444cliqued);
                }
                return false;
            }
        });


        //LONG

        long1.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                longTouch(event,long1Img,long1cliqued,longHold1,firstTouch1,animSetXYL1);

                return false;
            }
        });

        long2.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                longTouch(event,long2Img,long2cliqued,longHold2,firstTouch2,animSetXYL2);
                return false;
            }
        });

        long3.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                longTouch(event,long3Img,long3cliqued,longHold3,firstTouch3,animSetXYL3);
                return false;
            }
        });

        long4.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                longTouch(event,long4Img,long4cliqued,longHold4,firstTouch4,animSetXYL4);
                return false;
            }
        });


        layoutFail.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                if(start[0]) {
                    gameOver(musique);                }
            }
        });




        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                start[0] = true;
                startBtn.setVisibility(Button.GONE);
                startBtn2.setVisibility(Button.GONE);
                musique=MediaPlayer.create(MainActivity.this,R.raw.snk1);

                snk1(); //LANCEMENT
            }
        });

        startBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                start[0] = true;
                startBtn.setVisibility(Button.GONE);
                startBtn2.setVisibility(Button.GONE);
                musique=MediaPlayer.create(MainActivity.this,R.raw.demon_slayer1);
                demonSlayer1();
            }
        });



    }

    @Override
    protected void onPause() {

        super.onPause();
        if (musique.isPlaying()) musique.stop();

    }


    void noteTouch(Button noteImg,Boolean[] clicked) {
        if (!clicked[0]) {
            int intscore = parseInt(score.getText().toString()) + 100;
            score.setText(String.valueOf(intscore));
            noteImg.setAlpha(0.3f);
            clicked[0] = true;

            vibrator.vibrate(50); //VIBRATE
        }
    }

    void longTouch(MotionEvent event,Button longImg,Boolean[] cliqued, boolean[] hold,double[] firstTouch,AnimatorSet animSet){

        longImg.setAlpha(0.3f);;
        cliqued[0] = true;


        if (event.getAction()==MotionEvent.ACTION_DOWN) {
            hold[0]=true;
            firstTouch[0] = System.currentTimeMillis();


        } else if (event.getAction()==MotionEvent.ACTION_UP) {

            hold[0] = false;
            if(animSet.isStarted()){
                addLongPoint(System.currentTimeMillis()-firstTouch[0]);
            }
        }


    }

    void restartAnimNote(Button note,Button noteImg,Boolean[] cliqued){
        if(!cliqued[0]){
            gameOver(musique); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
        }
        cliqued[0] = false;

        note.setVisibility(Button.GONE);
        noteImg.setVisibility(Button.GONE);
    }

    void restartAnimLong(Button longue,Button longImg,Boolean hold,Boolean[] cliqued,double firstTouch){

        if(hold) {   //On prend le deuxieme temps
            addLongPoint(System.currentTimeMillis()-firstTouch);
        }

        if(!cliqued[0]){
            gameOver(musique);                }
        cliqued[0] = false;
        longue.setVisibility(Button.GONE);
        longImg.setVisibility(Button.GONE);

    }


    void gameOver(MediaPlayer music){

        if(!arret) {

            music.stop();

            arret = true;
            Intent i = new Intent(MainActivity.this, game_over.class);
            String s = score.getText().toString();
            i.putExtra("score", s);

            startActivity(i);

            overridePendingTransition(R.anim.fadein, R.anim.fadeout);

        }
    }




    void addLongPoint(double seconds){
        double dbscore = parseInt(score.getText().toString())+(seconds/5);
        int intscore = (int) dbscore;
        score.setText(String.valueOf(intscore));
    }


    void fall(int[] tab){
        if(!arret) {

            if (tab[indice] == 1) {
                if (!animSetXY1.isStarted()) {
                    note1Img.setVisibility(Button.VISIBLE);
                    note1.setVisibility(Button.VISIBLE);
                    animSetXY1.start();
                } else {
                    if (!animSetXY11.isStarted()) {
                        note11Img.setVisibility(Button.VISIBLE);
                        note11.setVisibility(Button.VISIBLE);
                        animSetXY11.start();
                    } else {
                        note111Img.setVisibility(Button.VISIBLE);
                        note111.setVisibility(Button.VISIBLE);
                        animSetXY111.start();
                    }
                }
            } else if (tab[indice] == 2) {
                if (!animSetXY2.isStarted()) {
                    note2Img.setVisibility(Button.VISIBLE);
                    note2.setVisibility(Button.VISIBLE);
                    animSetXY2.start();


                } else {
                    if (!animSetXY22.isStarted()) {
                        note22Img.setVisibility(Button.VISIBLE);
                        note22.setVisibility(Button.VISIBLE);
                        animSetXY22.start();
                    } else {
                        note222Img.setVisibility(Button.VISIBLE);
                        note222.setVisibility(Button.VISIBLE);
                        animSetXY222.start();
                    }
                }
            } else if (tab[indice] == 3) {
                if (!animSetXY3.isStarted()) {
                    note3Img.setVisibility(Button.VISIBLE);
                    note3.setVisibility(Button.VISIBLE);
                    animSetXY3.start();
                } else {
                    if (!animSetXY33.isStarted()) {
                        note33Img.setVisibility(Button.VISIBLE);
                        note33.setVisibility(Button.VISIBLE);
                        animSetXY33.start();
                    } else {
                        note333Img.setVisibility(Button.VISIBLE);
                        note333.setVisibility(Button.VISIBLE);
                        animSetXY333.start();
                    }
                }
            } else if (tab[indice] == 4) {
                if (!animSetXY4.isStarted()) {
                    note4Img.setVisibility(Button.VISIBLE);
                    note4.setVisibility(Button.VISIBLE);
                    animSetXY4.start();
                } else {
                    if (!animSetXY44.isStarted()) {
                        note44Img.setVisibility(Button.VISIBLE);
                        note44.setVisibility(Button.VISIBLE);
                        animSetXY44.start();
                    } else {
                        note444Img.setVisibility(Button.VISIBLE);
                        note444.setVisibility(Button.VISIBLE);
                        animSetXY444.start();
                    }
                }
            } else if (tab[indice] == 12) {
                if (!animSetXY1.isStarted()) {
                    note1Img.setVisibility(Button.VISIBLE);
                    note1.setVisibility(Button.VISIBLE);
                    animSetXY1.start();
                } else {
                    if (!animSetXY11.isStarted()) {
                        note11Img.setVisibility(Button.VISIBLE);
                        note11.setVisibility(Button.VISIBLE);
                        animSetXY11.start();
                    } else {
                        note111Img.setVisibility(Button.VISIBLE);
                        note111.setVisibility(Button.VISIBLE);
                        animSetXY111.start();
                    }
                }
                if (!animSetXY2.isStarted()) {
                    note2Img.setVisibility(Button.VISIBLE);
                    note2.setVisibility(Button.VISIBLE);
                    animSetXY2.start();
                } else {
                    if (!animSetXY22.isStarted()) {
                        note22Img.setVisibility(Button.VISIBLE);
                        note22.setVisibility(Button.VISIBLE);
                        animSetXY22.start();
                    } else {
                        note222Img.setVisibility(Button.VISIBLE);
                        note222.setVisibility(Button.VISIBLE);
                        animSetXY222.start();
                    }
                }
            } else if (tab[indice] == 13) {
                if (!animSetXY1.isStarted()) {
                    note1Img.setVisibility(Button.VISIBLE);
                    note1.setVisibility(Button.VISIBLE);
                    animSetXY1.start();
                } else {
                    if (!animSetXY11.isStarted()) {
                        note11Img.setVisibility(Button.VISIBLE);
                        note11.setVisibility(Button.VISIBLE);
                        animSetXY11.start();
                    } else {
                        note111Img.setVisibility(Button.VISIBLE);
                        note111.setVisibility(Button.VISIBLE);
                        animSetXY111.start();
                    }
                }
                if (!animSetXY3.isStarted()) {
                    note3Img.setVisibility(Button.VISIBLE);
                    note3.setVisibility(Button.VISIBLE);
                    animSetXY3.start();
                } else {
                    if (!animSetXY33.isStarted()) {
                        note33Img.setVisibility(Button.VISIBLE);
                        note33.setVisibility(Button.VISIBLE);
                        animSetXY33.start();
                    } else {
                        note333Img.setVisibility(Button.VISIBLE);
                        note333.setVisibility(Button.VISIBLE);
                        animSetXY333.start();
                    }
                }
            } else if (tab[indice] == 14) {
                if (!animSetXY1.isStarted()) {
                    note1Img.setVisibility(Button.VISIBLE);
                    note1.setVisibility(Button.VISIBLE);
                    animSetXY1.start();
                } else {
                    if (!animSetXY11.isStarted()) {
                        note11Img.setVisibility(Button.VISIBLE);
                        note11.setVisibility(Button.VISIBLE);
                        animSetXY11.start();
                    } else {
                        note111Img.setVisibility(Button.VISIBLE);
                        note111.setVisibility(Button.VISIBLE);
                        animSetXY111.start();
                    }
                }
                if (!animSetXY4.isStarted()) {
                    note4Img.setVisibility(Button.VISIBLE);
                    note4.setVisibility(Button.VISIBLE);
                    animSetXY4.start();
                } else {
                    if (!animSetXY44.isStarted()) {
                        note44Img.setVisibility(Button.VISIBLE);
                        note44.setVisibility(Button.VISIBLE);
                        animSetXY44.start();
                    } else {
                        note444Img.setVisibility(Button.VISIBLE);
                        note444.setVisibility(Button.VISIBLE);
                        animSetXY444.start();
                    }
                }
            } else if (tab[indice] == 23) {
                if (!animSetXY2.isStarted()) {
                    note2Img.setVisibility(Button.VISIBLE);
                    note2.setVisibility(Button.VISIBLE);
                    animSetXY2.start();
                } else {
                    if (!animSetXY22.isStarted()) {
                        note22Img.setVisibility(Button.VISIBLE);
                        note22.setVisibility(Button.VISIBLE);
                        animSetXY22.start();
                    } else {
                        note222Img.setVisibility(Button.VISIBLE);
                        note222.setVisibility(Button.VISIBLE);
                        animSetXY222.start();
                    }
                }
                if (!animSetXY3.isStarted()) {
                        note3Img.setVisibility(Button.VISIBLE);
                        note3.setVisibility(Button.VISIBLE);
                        animSetXY3.start();
                    } else {
                        if (!animSetXY33.isStarted()) {
                            note33Img.setVisibility(Button.VISIBLE);
                            note33.setVisibility(Button.VISIBLE);
                            animSetXY33.start();
                        } else {
                            note333Img.setVisibility(Button.VISIBLE);
                            note333.setVisibility(Button.VISIBLE);
                            animSetXY333.start();
                        }
                    }
            } else if (tab[indice] == 24) {
                if (!animSetXY2.isStarted()) {
                    note2Img.setVisibility(Button.VISIBLE);
                    note2.setVisibility(Button.VISIBLE);
                    animSetXY2.start();
                } else {
                    if (!animSetXY22.isStarted()) {
                        note22Img.setVisibility(Button.VISIBLE);
                        note22.setVisibility(Button.VISIBLE);
                        animSetXY22.start();
                    } else {
                        note222Img.setVisibility(Button.VISIBLE);
                        note222.setVisibility(Button.VISIBLE);
                        animSetXY222.start();
                    }
                }
                if (!animSetXY4.isStarted()) {
                    note4Img.setVisibility(Button.VISIBLE);
                    note4.setVisibility(Button.VISIBLE);
                    animSetXY4.start();
                } else {
                    if (!animSetXY44.isStarted()) {
                        note44Img.setVisibility(Button.VISIBLE);
                        note44.setVisibility(Button.VISIBLE);
                        animSetXY44.start();
                    } else {
                        note444Img.setVisibility(Button.VISIBLE);
                        note444.setVisibility(Button.VISIBLE);
                        animSetXY444.start();
                    }
                }
            } else if (tab[indice] == 34) {
                if (!animSetXY3.isStarted()) {
                    note3Img.setVisibility(Button.VISIBLE);
                    note3.setVisibility(Button.VISIBLE);
                    animSetXY3.start();
                } else {
                    if (!animSetXY33.isStarted()) {
                        note33Img.setVisibility(Button.VISIBLE);
                        note33.setVisibility(Button.VISIBLE);
                        animSetXY33.start();
                    } else {
                        note333Img.setVisibility(Button.VISIBLE);
                        note333.setVisibility(Button.VISIBLE);
                        animSetXY333.start();
                    }
                }
                if (!animSetXY4.isStarted()) {
                    note4Img.setVisibility(Button.VISIBLE);
                    note4.setVisibility(Button.VISIBLE);
                    animSetXY4.start();
                } else {
                    if (!animSetXY44.isStarted()) {
                        note44Img.setVisibility(Button.VISIBLE);
                        note44.setVisibility(Button.VISIBLE);
                        animSetXY44.start();
                    } else {
                        note444Img.setVisibility(Button.VISIBLE);
                        note444.setVisibility(Button.VISIBLE);
                        animSetXY444.start();
                    }
                }
            } else if (tab[indice] == 123) {
                if (!animSetXY1.isStarted()) {
                    note1Img.setVisibility(Button.VISIBLE);
                    note1.setVisibility(Button.VISIBLE);
                    animSetXY1.start();
                } else {
                    if (!animSetXY11.isStarted()) {
                        note11Img.setVisibility(Button.VISIBLE);
                        note11.setVisibility(Button.VISIBLE);
                        animSetXY11.start();
                    } else {
                        note111Img.setVisibility(Button.VISIBLE);
                        note111.setVisibility(Button.VISIBLE);
                        animSetXY111.start();
                    }
                }
                if (!animSetXY2.isStarted()) {
                    note2Img.setVisibility(Button.VISIBLE);
                    note2.setVisibility(Button.VISIBLE);
                    animSetXY2.start();
                } else {
                    if (!animSetXY22.isStarted()) {
                        note22Img.setVisibility(Button.VISIBLE);
                        note22.setVisibility(Button.VISIBLE);
                        animSetXY22.start();
                    } else {
                        note222Img.setVisibility(Button.VISIBLE);
                        note222.setVisibility(Button.VISIBLE);
                        animSetXY222.start();
                    }
                }
                if (!animSetXY3.isStarted()) {
                    note3Img.setVisibility(Button.VISIBLE);
                    note3.setVisibility(Button.VISIBLE);
                    animSetXY3.start();
                } else {
                    if (!animSetXY33.isStarted()) {
                        note33Img.setVisibility(Button.VISIBLE);
                        note33.setVisibility(Button.VISIBLE);
                        animSetXY33.start();
                    } else {
                        note333Img.setVisibility(Button.VISIBLE);
                        note333.setVisibility(Button.VISIBLE);
                        animSetXY333.start();
                    }
                }
            } else if (tab[indice] == 124) {
                if (!animSetXY1.isStarted()) {
                    note1Img.setVisibility(Button.VISIBLE);
                    note1.setVisibility(Button.VISIBLE);
                    animSetXY1.start();
                } else {
                    if (!animSetXY11.isStarted()) {
                        note11Img.setVisibility(Button.VISIBLE);
                        note11.setVisibility(Button.VISIBLE);
                        animSetXY11.start();
                    } else {
                        note111Img.setVisibility(Button.VISIBLE);
                        note111.setVisibility(Button.VISIBLE);
                        animSetXY111.start();
                    }
                }
                if (!animSetXY2.isStarted()) {
                    note2Img.setVisibility(Button.VISIBLE);
                    note2.setVisibility(Button.VISIBLE);
                    animSetXY2.start();
                } else {
                    if (!animSetXY22.isStarted()) {
                        note22Img.setVisibility(Button.VISIBLE);
                        note22.setVisibility(Button.VISIBLE);
                        animSetXY22.start();
                    } else {
                        note222Img.setVisibility(Button.VISIBLE);
                        note222.setVisibility(Button.VISIBLE);
                        animSetXY222.start();
                    }
                }
                if (!animSetXY4.isStarted()) {
                    note4Img.setVisibility(Button.VISIBLE);
                    note4.setVisibility(Button.VISIBLE);
                    animSetXY4.start();
                } else {
                    if (!animSetXY44.isStarted()) {
                        note44Img.setVisibility(Button.VISIBLE);
                        note44.setVisibility(Button.VISIBLE);
                        animSetXY44.start();
                    } else {
                        note444Img.setVisibility(Button.VISIBLE);
                        note444.setVisibility(Button.VISIBLE);
                        animSetXY444.start();
                    }
                }
            } else if (tab[indice] == 134) {
                if (!animSetXY1.isStarted()) {
                    note1Img.setVisibility(Button.VISIBLE);
                    note1.setVisibility(Button.VISIBLE);
                    animSetXY1.start();
                } else {
                    if (!animSetXY11.isStarted()) {
                        note11Img.setVisibility(Button.VISIBLE);
                        note11.setVisibility(Button.VISIBLE);
                        animSetXY11.start();
                    } else {
                        note111Img.setVisibility(Button.VISIBLE);
                        note111.setVisibility(Button.VISIBLE);
                        animSetXY111.start();
                    }
                }
                if (!animSetXY3.isStarted()) {
                    note3Img.setVisibility(Button.VISIBLE);
                    note3.setVisibility(Button.VISIBLE);
                    animSetXY3.start();
                } else {
                    if (!animSetXY33.isStarted()) {
                        note33Img.setVisibility(Button.VISIBLE);
                        note33.setVisibility(Button.VISIBLE);
                        animSetXY33.start();
                    } else { note333Img.setVisibility(Button.VISIBLE);
                        note333.setVisibility(Button.VISIBLE);
                        animSetXY333.start();
                    }
                }
                if (!animSetXY4.isStarted()) {
                    note4Img.setVisibility(Button.VISIBLE);
                    note4.setVisibility(Button.VISIBLE);
                    animSetXY4.start();
                } else {
                    if (!animSetXY44.isStarted()) {
                        note44Img.setVisibility(Button.VISIBLE);
                        note44.setVisibility(Button.VISIBLE);
                        animSetXY44.start();
                    } else {
                        note444Img.setVisibility(Button.VISIBLE);
                        note444.setVisibility(Button.VISIBLE);
                        animSetXY444.start();
                    }
                }
                }
            else if (tab[indice] == 234) {
                if (!animSetXY2.isStarted()) {
                    note2Img.setVisibility(Button.VISIBLE);
                    note2.setVisibility(Button.VISIBLE);
                    animSetXY2.start();
                } else {
                    if (!animSetXY22.isStarted()) {
                        note22Img.setVisibility(Button.VISIBLE);
                        note22.setVisibility(Button.VISIBLE);
                        animSetXY22.start();
                    } else {
                        note222Img.setVisibility(Button.VISIBLE);
                        note222.setVisibility(Button.VISIBLE);
                        animSetXY222.start();
                    }
                }
                if (!animSetXY3.isStarted()) {
                    note3Img.setVisibility(Button.VISIBLE);
                    note3.setVisibility(Button.VISIBLE);
                    animSetXY3.start();
                } else {
                    if (!animSetXY33.isStarted()) {
                        note33Img.setVisibility(Button.VISIBLE);
                        note33.setVisibility(Button.VISIBLE);
                        animSetXY33.start();
                    } else {
                        note333Img.setVisibility(Button.VISIBLE);
                        note333.setVisibility(Button.VISIBLE);
                        animSetXY333.start();
                    }
                }
                if (!animSetXY4.isStarted()) {
                    note4Img.setVisibility(Button.VISIBLE);
                    note4.setVisibility(Button.VISIBLE);
                    animSetXY4.start();
                } else {
                    if (!animSetXY44.isStarted()) {
                        note44Img.setVisibility(Button.VISIBLE);
                        note44.setVisibility(Button.VISIBLE);
                        animSetXY44.start();
                    } else {
                        note444Img.setVisibility(Button.VISIBLE);
                        note444.setVisibility(Button.VISIBLE);
                        animSetXY444.start();
                    }
                }
            } else if (tab[indice] == 1234) {
                if (!animSetXY1.isStarted()) {
                    note1Img.setVisibility(Button.VISIBLE);
                    note1.setVisibility(Button.VISIBLE);
                    animSetXY1.start();
                } else {
                    if (!animSetXY11.isStarted()) {
                        note11Img.setVisibility(Button.VISIBLE);
                        note11.setVisibility(Button.VISIBLE);
                        animSetXY11.start();
                    } else {
                        note111Img.setVisibility(Button.VISIBLE);
                        note111.setVisibility(Button.VISIBLE);
                        animSetXY111.start();
                    }
                }
                if (!animSetXY2.isStarted()) {
                    note2Img.setVisibility(Button.VISIBLE);
                    note2.setVisibility(Button.VISIBLE);
                    animSetXY2.start();
                    } else {
                    if (!animSetXY22.isStarted()) {
                        note22Img.setVisibility(Button.VISIBLE);
                        note22.setVisibility(Button.VISIBLE);
                        animSetXY22.start();
                    } else {
                        note222Img.setVisibility(Button.VISIBLE);
                        note222.setVisibility(Button.VISIBLE);
                        animSetXY222.start();
                    }
                }
                if (!animSetXY3.isStarted()) {
                    note3Img.setVisibility(Button.VISIBLE);
                    note3.setVisibility(Button.VISIBLE);
                    animSetXY3.start();
                } else {
                    if (!animSetXY33.isStarted()) {
                        note33Img.setVisibility(Button.VISIBLE);
                        note33.setVisibility(Button.VISIBLE);
                        animSetXY33.start();
                    } else {
                        note333Img.setVisibility(Button.VISIBLE);
                        note333.setVisibility(Button.VISIBLE);
                        animSetXY333.start();
                    }
                }
                if (!animSetXY4.isStarted()) {
                    note4Img.setVisibility(Button.VISIBLE);
                    note4.setVisibility(Button.VISIBLE);
                    animSetXY4.start();
                } else {
                    if (!animSetXY44.isStarted()) {
                        note44Img.setVisibility(Button.VISIBLE);
                        note44.setVisibility(Button.VISIBLE);
                        animSetXY44.start();
                    } else {
                        note444Img.setVisibility(Button.VISIBLE);
                        note444.setVisibility(Button.VISIBLE);
                        animSetXY444.start();
                    }
                }
            } else if (tab[indice] == 11) {
                if (!animSetXYL1.isStarted()) {
                    long1Img.setVisibility(Button.VISIBLE);
                    long1.setVisibility(Button.VISIBLE);
                    animSetXYL1.start();
                }
            } else if (tab[indice] == 22) {
                if (!animSetXYL2.isStarted()) {
                    long2Img.setVisibility(Button.VISIBLE);
                    long2.setVisibility(Button.VISIBLE);
                    animSetXYL2.start();
                }
            } else if (tab[indice] == 33) {
                if (!animSetXYL3.isStarted()) {
                    long3Img.setVisibility(Button.VISIBLE);
                    long3.setVisibility(Button.VISIBLE);
                    animSetXYL3.start();
                }
            } else if (tab[indice] == 44) {
                if (!animSetXYL4.isStarted()) {
                    long4Img.setVisibility(Button.VISIBLE);
                    long4.setVisibility(Button.VISIBLE);
                    animSetXYL4.start();
                }
            }
            //if tab [indice] == 9999 on passe au suivant : permet d'attendre plus longtemps avant la prochaine note

            indice = indice + 1;
            if (indice == tab.length) {
                indice = 0;
            }

        }
    }


    public void snk1(){
        animSetXY1.setDuration(speedNote);
        animSetXY2.setDuration(speedNote);
        animSetXY3.setDuration(speedNote);
        animSetXY4.setDuration(speedNote);

        animSetXY11.setDuration(speedNote);
        animSetXY22.setDuration(speedNote);
        animSetXY33.setDuration(speedNote);
        animSetXY44.setDuration(speedNote);

        animSetXY111.setDuration(speedNote);
        animSetXY222.setDuration(speedNote);
        animSetXY333.setDuration(speedNote);
        animSetXY444.setDuration(speedNote);

        animSetXYL1.setDuration(speedLong);
        animSetXYL2.setDuration(speedLong);
        animSetXYL3.setDuration(speedLong);
        animSetXYL4.setDuration(speedLong);

        indice=0;


        musique.start();

        new CountDownTimer((long)(3200/multiplier), (long)(1000/multiplier)) {

            @Override
            public void onTick(long millisUntilFinished) {
                // do something after 1s
            }

            @Override
            public void onFinish() {


                new CountDownTimer((long)(10400/multiplier), (long)(400/multiplier)) {

                    @Override
                    public void onTick(long millisUntilFinished) {

                        fall(snk1_tab);

                    }

                    @Override
                    public void onFinish() {


                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            public void run() {

                                mainLayout2.setBackgroundResource(R.drawable.degrad_yellow_pink);
                                mainLayout2.startAnimation(transition);
                                mainLayout.setBackgroundResource(R.drawable.degrad_yellow_pink);


                                new CountDownTimer((long)(22700/multiplier), (long)(400/multiplier)) {

                                    @Override
                                    public void onTick(long millisUntilFinished) {

                                        fall(snk1_tab);
                                    }

                                    @Override
                                    public void onFinish() {

                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            public void run() {
                                                new CountDownTimer((long)(3100/multiplier), (long)(270/multiplier)) {

                                                    @Override
                                                    public void onTick(long millisUntilFinished) {


                                                        fall(snk1_tab);
                                                    }

                                                    @Override
                                                    public void onFinish() {

                                                        Handler handler = new Handler();
                                                        handler.postDelayed(new Runnable() {
                                                            public void run() {


                                                                Handler handler = new Handler(); //POUR l'animation
                                                                handler.postDelayed(new Runnable() {
                                                                    public void run() {
                                                                        mainLayout2.setBackgroundResource(R.drawable.degrad_red);
                                                                        mainLayout2.startAnimation(transition);
                                                                        mainLayout.setBackgroundResource(R.drawable.degrad_red);
                                                                    }
                                                                }, (long)(5300/multiplier));



                                                                new CountDownTimer((long)(46000/multiplier), (long)(400/multiplier)) {

                                                                    @Override
                                                                    public void onTick(long millisUntilFinished) {
                                                                        fall(snk1_tab);
                                                                    }

                                                                    @Override
                                                                    public void onFinish() { // RECOMMENCER PLUS RAPIDEMENT

                                                                        Handler handler = new Handler();
                                                                        handler.postDelayed(new Runnable() {
                                                                            @RequiresApi(api = Build.VERSION_CODES.M)
                                                                            public void run() {


                                                                                if(!arret){
                                                                                    multiplier = multiplier +(0.05f);
                                                                                    musique.setPlaybackParams(musique.getPlaybackParams().setSpeed(multiplier));
                                                                                    speedNote=(int)(speedNote/multiplier);
                                                                                    speedLong=(int)(speedLong/multiplier);
                                                                                    mainLayout2.setBackgroundResource(R.drawable.degrad_pink_blue);
                                                                                    mainLayout2.startAnimation(transition);
                                                                                    mainLayout.setBackgroundResource(R.drawable.degrad_pink_blue);
                                                                                    snk1();
                                                                                }


                                                                            }


                                                                        }, (long)(5000));

                                                                    }

                                                                }.start();


                                                            }
                                                        }, (long)(200/multiplier));

                                                    }

                                                }.start();

                                            }
                                        }, (long)(300/multiplier));
                                        //

                                    }

                                }.start();


                            }
                        }, (long)(2000/multiplier));


                    }

                }.start();

            }

        }.start();




    }




    public void demonSlayer1(){

        animSetXY1.setDuration(speedNote);
        animSetXY2.setDuration(speedNote);
        animSetXY3.setDuration(speedNote);
        animSetXY4.setDuration(speedNote);

        animSetXY11.setDuration(speedNote);
        animSetXY22.setDuration(speedNote);
        animSetXY33.setDuration(speedNote);
        animSetXY44.setDuration(speedNote);

        animSetXY111.setDuration(speedNote);
        animSetXY222.setDuration(speedNote);
        animSetXY333.setDuration(speedNote);
        animSetXY444.setDuration(speedNote);

        animSetXYL1.setDuration(speedLong);
        animSetXYL2.setDuration(speedLong);
        animSetXYL3.setDuration(speedLong);
        animSetXYL4.setDuration(speedLong);

        indice=0;


        musique.start();


        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {public void run() {


            new CountDownTimer((long)(420/multiplier), (long)(200/multiplier)) {

                @Override
                public void onTick(long millisUntilFinished) {
                    fall(tab_demonSlayer1);
                }

                @Override
                public void onFinish() {
                    indice=3;
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {public void run() {


                    new CountDownTimer((long)(420/multiplier), (long)(200/multiplier)) {

                        @Override
                        public void onTick(long millisUntilFinished) {
                            fall(tab_demonSlayer1);
                        }

                        @Override
                        public void onFinish() {
                            indice=6;

                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {public void run() {

                                new CountDownTimer((long)(1620/multiplier), (long)(200/multiplier)) {

                                    @Override
                                    public void onTick(long millisUntilFinished) {
                                        fall(tab_demonSlayer1);
                                    }

                                    @Override
                                    public void onFinish() {

                                            indice =15;
                                            Handler handler = new Handler();
                                            handler.postDelayed(new Runnable() {public void run() {


                                                new CountDownTimer((long)(420/multiplier), (long)(200/multiplier)) {

                                                    @Override
                                                    public void onTick(long millisUntilFinished) {
                                                        fall(tab_demonSlayer1);
                                                    }

                                                    @Override
                                                    public void onFinish() {

                                                        indice=18;

                                                        handler.postDelayed(new Runnable() {public void run() {

                                                            new CountDownTimer((long)(420/multiplier), (long)(200/multiplier)) {

                                                                @Override
                                                                public void onTick(long millisUntilFinished) {
                                                                    fall(tab_demonSlayer1);
                                                                }

                                                                @Override
                                                                public void onFinish() {

                                                                    indice=21;

                                                                    Handler handler = new Handler();
                                                                    handler.postDelayed(new Runnable() {public void run() {


                                                                        new CountDownTimer((long)(620/multiplier), (long)(300/multiplier)) {

                                                                            @Override
                                                                            public void onTick(long millisUntilFinished) {

                                                                                fall(tab_demonSlayer1);
                                                                            }

                                                                            @Override
                                                                            public void onFinish() {

                                                                                indice=24;
                                                                                    Handler handler = new Handler();
                                                                                    handler.postDelayed(new Runnable() {public void run() {


                                                                                        new CountDownTimer((long)(6500/multiplier), (long)(300/multiplier)) {

                                                                                            @Override
                                                                                            public void onTick(long millisUntilFinished) {
                                                                                                fall(tab_demonSlayer1);
                                                                                            }

                                                                                            @Override
                                                                                            public void onFinish() {
                                                                                                indice =46;

                                                                                                Handler handler = new Handler();
                                                                                                handler.postDelayed(new Runnable() {public void run() {


                                                                                                    new CountDownTimer((long)(2000/multiplier),(long)(300/multiplier)) {

                                                                                                        @Override
                                                                                                        public void onTick(long millisUntilFinished) {
                                                                                                            fall(tab_demonSlayer1);
                                                                                                        }

                                                                                                        @Override
                                                                                                        public void onFinish() {
                                                                                                            indice=53;

                                                                                                            Handler handler = new Handler();
                                                                                                            handler.postDelayed(new Runnable() {public void run() {

                                                                                                                new CountDownTimer((long)(820/multiplier),(long)(200/multiplier)) {  //DOUBLES RAPIDES

                                                                                                                    @Override
                                                                                                                    public void onTick(long millisUntilFinished) {
                                                                                                                        fall(tab_demonSlayer1);
                                                                                                                    }

                                                                                                                    @Override
                                                                                                                    public void onFinish() {
                                                                                                                        indice =58;

                                                                                                                        Handler handler = new Handler();
                                                                                                                        handler.postDelayed(new Runnable() {public void run() {


                                                                                                                            new CountDownTimer((long)(3320/multiplier),(long)(300/multiplier)) {

                                                                                                                                @Override
                                                                                                                                public void onTick(long millisUntilFinished) {
                                                                                                                                    fall(tab_demonSlayer1);
                                                                                                                                }

                                                                                                                                @Override
                                                                                                                                public void onFinish() {
                                                                                                                                    indice=70;
                                                                                                                                    Handler handler = new Handler();
                                                                                                                                    handler.postDelayed(new Runnable() {public void run() {

                                                                                                                                        new CountDownTimer((long)(7700/multiplier),(long)(300/multiplier)) {

                                                                                                                                            @Override
                                                                                                                                            public void onTick(long millisUntilFinished) {
                                                                                                                                                fall(tab_demonSlayer1);
                                                                                                                                            }

                                                                                                                                            @Override
                                                                                                                                            public void onFinish() {
                                                                                                                                                indice=97;

                                                                                                                                                Handler handler = new Handler();
                                                                                                                                                handler.postDelayed(new Runnable() {public void run() {

                                                                                                                                                    new CountDownTimer((long)(820/multiplier),(long)(200/multiplier)) {

                                                                                                                                                        @Override
                                                                                                                                                        public void onTick(long millisUntilFinished) {

                                                                                                                                                            fall(tab_demonSlayer1);
                                                                                                                                                        }

                                                                                                                                                        @Override
                                                                                                                                                        public void onFinish() {
                                                                                                                                                            indice=102;
                                                                                                                                                            Handler handler = new Handler();
                                                                                                                                                            handler.postDelayed(new Runnable() {public void run() {

                                                                                                                                                                new CountDownTimer((long)(1700/multiplier),(long)(300/multiplier)) {

                                                                                                                                                                    @Override
                                                                                                                                                                    public void onTick(long millisUntilFinished) {
                                                                                                                                                                        fall(tab_demonSlayer1);
                                                                                                                                                                    }

                                                                                                                                                                    @Override
                                                                                                                                                                    public void onFinish() {
                                                                                                                                                                        indice=107;

                                                                                                                                                                        Handler handler = new Handler();
                                                                                                                                                                        handler.postDelayed(new Runnable() {public void run() {

                                                                                                                                                                            new CountDownTimer((long)(820/multiplier),(long)(200/multiplier)) {

                                                                                                                                                                                @Override
                                                                                                                                                                                public void onTick(long millisUntilFinished) {
                                                                                                                                                                                    fall(tab_demonSlayer1);
                                                                                                                                                                                }

                                                                                                                                                                                @Override
                                                                                                                                                                                public void onFinish() {
                                                                                                                                                                                    indice=112;
                                                                                                                                                                                    Handler handler = new Handler();
                                                                                                                                                                                    handler.postDelayed(new Runnable() {public void run() {

                                                                                                                                                                                        new CountDownTimer((long)(6320/multiplier),(long)(300/multiplier)) {

                                                                                                                                                                                            @Override
                                                                                                                                                                                            public void onTick(long millisUntilFinished) {
                                                                                                                                                                                                fall(tab_demonSlayer1);
                                                                                                                                                                                            }

                                                                                                                                                                                            @Override
                                                                                                                                                                                            public void onFinish() { //COMME AU DEBUT

                                                                                                                                                                                                indice=134;

                                                                                                                                                                                                Handler handler = new Handler();
                                                                                                                                                                                                handler.postDelayed(new Runnable() {public void run() {


                                                                                                                                                                                                    new CountDownTimer(420, 200) {

                                                                                                                                                                                                        @Override
                                                                                                                                                                                                        public void onTick(long millisUntilFinished) {
                                                                                                                                                                                                            fall(tab_demonSlayer1);
                                                                                                                                                                                                        }

                                                                                                                                                                                                        @Override
                                                                                                                                                                                                        public void onFinish() {
                                                                                                                                                                                                            indice=137;
                                                                                                                                                                                                            Handler handler = new Handler();
                                                                                                                                                                                                            handler.postDelayed(new Runnable() {public void run() {


                                                                                                                                                                                                                new CountDownTimer(420, 200) {

                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                    public void onTick(long millisUntilFinished) {
                                                                                                                                                                                                                        fall(tab_demonSlayer1);
                                                                                                                                                                                                                    }

                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                    public void onFinish() {
                                                                                                                                                                                                                        indice=140;

                                                                                                                                                                                                                        Handler handler = new Handler();
                                                                                                                                                                                                                        handler.postDelayed(new Runnable() {public void run() {

                                                                                                                                                                                                                            new CountDownTimer(1620, 200) {

                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                public void onTick(long millisUntilFinished) {
                                                                                                                                                                                                                                    fall(tab_demonSlayer1);
                                                                                                                                                                                                                                }

                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                public void onFinish() {
                                                                                                                                                                                                                                    indice=149;

                                                                                                                                                                                                                                    Handler handler = new Handler();
                                                                                                                                                                                                                                    handler.postDelayed(new Runnable() {public void run() {

                                                                                                                                                                                                                                        new CountDownTimer((long)(420/multiplier),(long)(200/multiplier)) {

                                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                                            public void onTick(long millisUntilFinished) {
                                                                                                                                                                                                                                                fall(tab_demonSlayer1);
                                                                                                                                                                                                                                            }

                                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                                            public void onFinish() {
                                                                                                                                                                                                                                                indice=152;

                                                                                                                                                                                                                                                Handler handler = new Handler();
                                                                                                                                                                                                                                                handler.postDelayed(new Runnable() {public void run() {

                                                                                                                                                                                                                                                    new CountDownTimer((long)(420/multiplier),(long)(200/multiplier)) {

                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                        public void onTick(long millisUntilFinished) {
                                                                                                                                                                                                                                                            fall(tab_demonSlayer1);
                                                                                                                                                                                                                                                        }

                                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                                        public void onFinish() {
                                                                                                                                                                                                                                                            indice=155;
                                                                                                                                                                                                                                                            Handler handler = new Handler();
                                                                                                                                                                                                                                                            handler.postDelayed(new Runnable() {public void run() {

                                                                                                                                                                                                                                                                new CountDownTimer((long)(620/multiplier),(long)(300/multiplier)) {

                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                    public void onTick(long millisUntilFinished) {
                                                                                                                                                                                                                                                                        fall(tab_demonSlayer1);
                                                                                                                                                                                                                                                                    }

                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                    public void onFinish() {

                                                                                                                                                                                                                                                                        Handler handler = new Handler();
                                                                                                                                                                                                                                                                        handler.postDelayed(new Runnable() {public void run() {

                                                                                                                                                                                                                                                                            new CountDownTimer((long)(29000/multiplier),(long)(300/multiplier)) {

                                                                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                                                                public void onTick(long millisUntilFinished) {
                                                                                                                                                                                                                                                                                    fall(tab_demonSlayer1);
                                                                                                                                                                                                                                                                                }

                                                                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                                                                public void onFinish() {


                                                                                                                                                                                                                                                                                    Handler handler = new Handler();
                                                                                                                                                                                                                                                                                    handler.postDelayed(new Runnable() {
                                                                                                                                                                                                                                                                                        @RequiresApi(api = Build.VERSION_CODES.M)
                                                                                                                                                                                                                                                                                        public void run() {

                                                                                                                                                                                                                                                                                            if(!arret){
                                                                                                                                                                                                                                                                                                multiplier = multiplier +(0.05f);
                                                                                                                                                                                                                                                                                                musique.setPlaybackParams(musique.getPlaybackParams().setSpeed(multiplier));
                                                                                                                                                                                                                                                                                                speedNote=(int)(speedNote/multiplier);
                                                                                                                                                                                                                                                                                                speedLong=(int)(speedLong/multiplier);

                                                                                                                                                                                                                                                                                                demonSlayer1();
                                                                                                                                                                                                                                                                                            }


                                                                                                                                                                                                                                                                                        }


                                                                                                                                                                                                                                                                                    }, (long)(5000));

                                                                                                                                                                                                                                                                                }

                                                                                                                                                                                                                                                                            }.start();

                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                        }, (long)(2000/multiplier));


                                                                                                                                                                                                                                                                    }

                                                                                                                                                                                                                                                                }.start();

                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                            }, (long)(1100/multiplier));

                                                                                                                                                                                                                                                        }

                                                                                                                                                                                                                                                    }.start();


                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                }, (long)(1000/multiplier));

                                                                                                                                                                                                                                            }

                                                                                                                                                                                                                                        }.start();


                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    }, (long)(1600/multiplier));

                                                                                                                                                                                                                                }

                                                                                                                                                                                                                            }.start();


                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        }, (long)(1200/multiplier));
                                                                                                                                                                                                                    }

                                                                                                                                                                                                                }.start();

                                                                                                                                                                                                            }
                                                                                                                                                                                                            }, (long)(1200/multiplier));


                                                                                                                                                                                                        }

                                                                                                                                                                                                    }.start();

                                                                                                                                                                                                }
                                                                                                                                                                                                }, (long)(1600/multiplier));

                                                                                                                                                                                            }

                                                                                                                                                                                        }.start();

                                                                                                                                                                                    }
                                                                                                                                                                                    }, (long)(400/multiplier));


                                                                                                                                                                                }

                                                                                                                                                                            }.start();

                                                                                                                                                                        }
                                                                                                                                                                        }, (long)(500/multiplier));

                                                                                                                                                                    }

                                                                                                                                                                }.start();

                                                                                                                                                            }
                                                                                                                                                            }, (long)(400/multiplier));

                                                                                                                                                        }

                                                                                                                                                    }.start();

                                                                                                                                                }
                                                                                                                                                }, (long)(500/multiplier));

                                                                                                                                            }

                                                                                                                                        }.start();

                                                                                                                                    }
                                                                                                                                    }, (long)(1000/multiplier));

                                                                                                                                }

                                                                                                                            }.start();


                                                                                                                        }
                                                                                                                        }, (long)(300/multiplier));

                                                                                                                    }

                                                                                                                }.start();


                                                                                                            }
                                                                                                            }, (long)(400/multiplier));

                                                                                                        }

                                                                                                    }.start();


                                                                                                }
                                                                                                }, (long)(800/multiplier));

                                                                                            }

                                                                                        }.start();


                                                                                    }
                                                                                    }, (long)(300/multiplier));


                                                                            }

                                                                        }.start();

                                                                    }
                                                                    }, (long)(1100/multiplier));



                                                                }

                                                            }.start();


                                                        }
                                                        }, (long)(1000/multiplier));


                                                    }

                                                }.start();



                                                }
                                                }, (long)(1600/multiplier));


                                    }

                                }.start();


                            }
                            }, (long)(1200/multiplier));
                        }

                    }.start();

                    }
                    }, (long)(1200/multiplier));


                }

            }.start();

        }
        }, (long)(500/multiplier));


    }



}




/*

Handler handler = new Handler();
handler.postDelayed(new Runnable() {public void run() {

}
}, (long)(2000/multiplier));




new CountDownTimer((long)(5000/multiplier),(long)(5000/multiplier)) {

            @Override
            public void onTick(long millisUntilFinished) {
                // do something after 1s
            }

            @Override
            public void onFinish() {


            }

        }.start();



        ANIMATOR TOGETHER

        ObjectAnimator animX = ObjectAnimator.ofFloat(myView, "x", 50f);
ObjectAnimator animY = ObjectAnimator.ofFloat(myView, "y", 100f);
AnimatorSet animSetXY = new AnimatorSet();
animSetXY.playTogether(animX, animY);
animSetXY.start();



PLAN : MEME CHOSE POUR LONG 2 3 4  , ajouter points en fonction des secondes, trouver animation de maintiens
 */
