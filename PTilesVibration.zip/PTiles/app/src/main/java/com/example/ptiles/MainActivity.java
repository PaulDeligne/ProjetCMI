package com.example.ptiles;

import static java.lang.Integer.parseInt;
import static java.lang.Integer.valueOf;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    Button startBtn;

    Button note1,note2,note3,note4,note11,note22,note33,note44,note111,note222,note333,note444;
    Button note1Img,note2Img,note3Img,note4Img,note11Img,note22Img,note33Img,note44Img,note111Img,note222Img,note333Img,note444Img;

    Button long1,long2,long3,long4;
    Button long1Img,long2Img,long3Img,long4Img;



    TextView score;
    LinearLayout layoutFail;
    RelativeLayout mainLayout2;
    ConstraintLayout mainLayout;




    AnimatorSet animSetXY1,animSetXY2,animSetXY3,animSetXY4,
            animSetXY11,animSetXY22,animSetXY33,animSetXY44,
            animSetXY111,animSetXY222,animSetXY333,animSetXY444,
            animSetXYL1,animSetXYL2,animSetXYL3,animSetXYL4;


    ObjectAnimator animX1,animY1,animX2,animY2,animX3,animY3,animX4,animY4,
            animX11,animY11,animX22,animY22,animX33,animY33,animX44,animY44,
            animX111,animY111,animX222,animY222,animX333,animY333,animX444,animY444,
            animXL1,animYL1,animXL2,animYL2,animXL3,animYL3,animXL4,animYL4;

    private static MediaPlayer snk;

    int speedNote=1000;
    int speedLong = 1300;
    float multiplier = 1.0f;

    int indice=0;
    int[] tab = {1,4,2,3,2,2,1,4,3,2,2,1,4,2,3,2,4,3,4,1,3,2,3,4,22  //[25] = coup 1
            ,4,3,2,1,2,1,2,1,4,3,4,3,11,3,4,3,4,2,1,4,2,1,3,44,1,2,3,4,2,2,4,3,1,2,2,3,1,3,1,4,2,11,3,3,4,2,1,4,3,1,3,2,4,3,2,4,2,3//57/58
            ,1,1,1,3,3,2,2,2,4,4,4 //12
            ,1,2,3,4,4,3,2,1,4,1,3,2,4,5,4,3,1,33,1,1,2,1,4,1,1,2,3,3,4,2,1,3,4,3,2,1,3,11,4,3,2,1,2,3,1,2,2,1,4,33,1,4,2,3,1,22,4,2,1,2,3,4,4,3,2,1,4,1,3,2,4,5,4,3,1,33,1,1,2,1,4,1,1,2,3,3,4,2,1,3,4,3,2,1,3,11,4,3,2,1,2,3,1,22,4,1,4,3,1,4,2,33 //120
    };

    //int[] tab = {11};



    //LONG VAR
    double longHoldTime1;
    double firstTouch1 = 0.;
    boolean longHold1;

    double longHoldTime2;
    double firstTouch2 = 0.;
    boolean longHold2;

    double longHoldTime3;
    double firstTouch3 = 0.;
    boolean longHold3;

    double longHoldTime4;
    double firstTouch4 = 0.;
    boolean longHold4;


    Animation transition;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startBtn = findViewById(R.id.startBtn);

        note1=findViewById(R.id.note1);
        note2=findViewById(R.id.note2);
        note3=findViewById(R.id.note3);
        note4=findViewById(R.id.note4);
        note11=findViewById(R.id.note11);
        note22=findViewById(R.id.note22);
        note33=findViewById(R.id.note33);
        note44=findViewById(R.id.note44);
        note111 = findViewById(R.id.note111);
        note222 = findViewById(R.id.note222);
        note333 = findViewById(R.id.note333);
        note444 = findViewById(R.id.note444);

        note1Img=findViewById(R.id.note1Img);
        note2Img=findViewById(R.id.note2Img);
        note3Img=findViewById(R.id.note3Img);
        note4Img=findViewById(R.id.note4Img);
        note11Img=findViewById(R.id.note11Img);
        note22Img=findViewById(R.id.note22Img);
        note33Img=findViewById(R.id.note33Img);
        note44Img=findViewById(R.id.note44Img);
        note111Img=findViewById(R.id.note111Img);
        note222Img=findViewById(R.id.note222Img);
        note333Img=findViewById(R.id.note333Img);
        note444Img=findViewById(R.id.note444Img);



        long1=findViewById(R.id.long1);
        long2=findViewById(R.id.long2);
        long3=findViewById(R.id.long3);
        long4=findViewById(R.id.long4);

        long1Img=findViewById(R.id.long1Img);
        long2Img=findViewById(R.id.long2Img);
        long3Img=findViewById(R.id.long3Img);
        long4Img=findViewById(R.id.long4Img);


        score = findViewById(R.id.score);

        layoutFail = findViewById(R.id.layoutFail);
        mainLayout = findViewById(R.id.mainLayout);
        mainLayout2=findViewById(R.id.mainLayout2);


        snk = MediaPlayer.create(MainActivity.this,R.raw.snk1);




        final boolean[] start = {false};


        //VERIFIER QUE LES NOTES SONT TOUTES CLIQUES
        final boolean[] note1cliqued = {false};
        final boolean[] note2cliqued = {false};
        final boolean[] note3cliqued = {false};
        final boolean[] note4cliqued = {false};
        final boolean[] note11cliqued = {false};
        final boolean[] note22cliqued = {false};
        final boolean[] note33cliqued = {false};
        final boolean[] note44cliqued = {false};
        final boolean[] note111cliqued = {false};
        final boolean[] note222cliqued = {false};
        final boolean[] note333cliqued = {false};
        final boolean[] note444cliqued = {false};
        final boolean[] long1cliqued = {false};
        final boolean[] long2cliqued = {false};
        final boolean[] long3cliqued = {false};
        final boolean[] long4cliqued = {false};

        //GET SCREEN SIZE

        DisplayMetrics metrics = this.getResources().getDisplayMetrics();
        int height = metrics.heightPixels; //LONGUEUR



        transition = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blinking_animation150);

        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);




        //SET ANIM POUR IMAGE ET BOUTON


        animX1 = ObjectAnimator.ofFloat(note1, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY1 = ObjectAnimator.ofFloat(note1Img, "y", -1000,height);
        animSetXY1 = new AnimatorSet();
        animSetXY1.playTogether(animX1, animY1);
        animSetXY1.setDuration(2500);
        animSetXY1.setInterpolator(new LinearInterpolator());


        animX2 = ObjectAnimator.ofFloat(note2, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY2 = ObjectAnimator.ofFloat(note2Img, "y", -1000,height);
        animSetXY2 = new AnimatorSet();
        animSetXY2.playTogether(animX2, animY2);
        animSetXY2.setDuration(2500);
        animSetXY2.setInterpolator(new LinearInterpolator());

        animX3 = ObjectAnimator.ofFloat(note3, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY3 = ObjectAnimator.ofFloat(note3Img, "y", -1000,height);
        animSetXY3 = new AnimatorSet();
        animSetXY3.playTogether(animX3, animY3);
        animSetXY3.setDuration(2500);
        animSetXY3.setInterpolator(new LinearInterpolator());


        animX4 = ObjectAnimator.ofFloat(note4, "y", -1200,height-200);//height = longueur ecran donc parcourstout l'ecran
        animY4 = ObjectAnimator.ofFloat(note4Img, "y", -1000,height);
        animSetXY4 = new AnimatorSet();
        animSetXY4.playTogether(animX4, animY4);
        animSetXY4.setDuration(2500);
        animSetXY4.setInterpolator(new LinearInterpolator());


        //SECONDES NOTES PAR LIGNES

        animX11 = ObjectAnimator.ofFloat(note11, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY11 = ObjectAnimator.ofFloat(note11Img, "y", -1000,height);
        animSetXY11 = new AnimatorSet();
        animSetXY11.playTogether(animX11, animY11);
        animSetXY11.setDuration(2500);
        animSetXY11.setInterpolator(new LinearInterpolator());


        animX22 = ObjectAnimator.ofFloat(note22, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY22 = ObjectAnimator.ofFloat(note22Img, "y", -1000,height);
        animSetXY22 = new AnimatorSet();
        animSetXY22.playTogether(animX22, animY22);
        animSetXY22.setDuration(2500);
        animSetXY22.setInterpolator(new LinearInterpolator());

        animX33 = ObjectAnimator.ofFloat(note33, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY33 = ObjectAnimator.ofFloat(note33Img, "y", -1000,height);
        animSetXY33 = new AnimatorSet();
        animSetXY33.playTogether(animX33, animY33);
        animSetXY33.setDuration(2500);
        animSetXY33.setInterpolator(new LinearInterpolator());

        animX44 = ObjectAnimator.ofFloat(note44, "y", -1200,height-200);//height = longueur ecran donc parcours tout l'ecran
        animY44 = ObjectAnimator.ofFloat(note44Img, "y", -1000,height);
        animSetXY44 = new AnimatorSet();
        animSetXY44.playTogether(animX44, animY44);
        animSetXY44.setDuration(2500);
        animSetXY44.setInterpolator(new LinearInterpolator());


        //TROISIEME PAR LIGNES

        animX111 = ObjectAnimator.ofFloat(note111, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY111 = ObjectAnimator.ofFloat(note111Img, "y", -1000,height);
        animSetXY111 = new AnimatorSet();
        animSetXY111.playTogether(animX111, animY111);
        animSetXY111.setDuration(2500);
        animSetXY111.setInterpolator(new LinearInterpolator());


        animX222 = ObjectAnimator.ofFloat(note222, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY222 = ObjectAnimator.ofFloat(note222Img, "y", -1000,height);
        animSetXY222 = new AnimatorSet();
        animSetXY222.playTogether(animX222, animY222);
        animSetXY222.setDuration(2500);
        animSetXY222.setInterpolator(new LinearInterpolator());

        animX333 = ObjectAnimator.ofFloat(note333, "y", -1200,height-200);//height = longueur ecran donc parcour tout l'ecran
        animY333 = ObjectAnimator.ofFloat(note333Img, "y", -1000,height);
        animSetXY333 = new AnimatorSet();
        animSetXY333.playTogether(animX333, animY333);
        animSetXY333.setDuration(2500);
        animSetXY333.setInterpolator(new LinearInterpolator());

        animX444 = ObjectAnimator.ofFloat(note444, "y", -1200,height-200);//height = longueur ecran donc parcours tout l'ecran
        animY444 = ObjectAnimator.ofFloat(note444Img, "y", -1000,height);
        animSetXY444 = new AnimatorSet();
        animSetXY444.playTogether(animX444, animY444);
        animSetXY444.setDuration(2500);
        animSetXY444.setInterpolator(new LinearInterpolator());


        //LONG

        animXL1 = ObjectAnimator.ofFloat(long1, "y", (-1*height),height);//height = longueur ecran donc parcours tout l'ecran
        animYL1 = ObjectAnimator.ofFloat(long1Img, "y", -1*height,height);
        animSetXYL1 = new AnimatorSet();
        animSetXYL1.playTogether(animXL1, animYL1);
        animSetXYL1.setDuration(2500);
        animSetXYL1.setInterpolator(new LinearInterpolator());

        animXL2 = ObjectAnimator.ofFloat(long2, "y", (-1*height),height);//height = longueur ecran donc parcours tout l'ecran
        animYL2 = ObjectAnimator.ofFloat(long2Img, "y", -1*height,height);
        animSetXYL2 = new AnimatorSet();
        animSetXYL2.playTogether(animXL2, animYL2);
        animSetXYL2.setDuration(2500);
        animSetXYL2.setInterpolator(new LinearInterpolator());

        animXL3 = ObjectAnimator.ofFloat(long3, "y", (-1*height),height);//height = longueur ecran donc parcours tout l'ecran
        animYL3 = ObjectAnimator.ofFloat(long3Img, "y", -1*height,height);
        animSetXYL3 = new AnimatorSet();
        animSetXYL3.playTogether(animXL3, animYL3);
        animSetXYL3.setDuration(2500);
        animSetXYL3.setInterpolator(new LinearInterpolator());

        animXL4 = ObjectAnimator.ofFloat(long4, "y", (-1*height),height);//height = longueur ecran donc parcours tout l'ecran
        animYL4 = ObjectAnimator.ofFloat(long4Img, "y", -1*height,height);
        animSetXYL4 = new AnimatorSet();
        animSetXYL4.playTogether(animXL4, animYL4);
        animSetXYL4.setDuration(2500);
        animSetXYL4.setInterpolator(new LinearInterpolator());







        animSetXY1.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                note1Img.setAlpha(1.0f);;

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {

                if(!note1cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                note1cliqued[0] = false;


                note1.setVisibility(Button.GONE);
                note1Img.setVisibility(Button.GONE);



            }

        });



        animSetXY2.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

                note2Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {

                if(!note2cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                note2cliqued[0] = false;


                note2.setVisibility(Button.GONE);
                note2Img.setVisibility(Button.GONE);

            }
        });



        animSetXY3.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

                note3Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {


                if(!note3cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu

                }
                note3cliqued[0] = false;


                note3.setVisibility(Button.GONE);
                note3Img.setVisibility(Button.GONE);

            }

        });




        animSetXY4.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                note4Img.setAlpha(1.0f);

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {


                if(!note4cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu

                }
                note4cliqued[0] = false;

                note4.setVisibility(Button.GONE);
                note4Img.setVisibility(Button.GONE);

            }
        });

        //


        animSetXY11.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                note11Img.setAlpha(1.0f);

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {

                if(!note11cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                note11cliqued[0] = false;


                note11.setVisibility(Button.GONE);
                note11Img.setVisibility(Button.GONE);



            }

        });



        animSetXY22.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

                note22Img.setAlpha(1.0f);

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {


                if(!note22cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                note22cliqued[0] = false;


                note22.setVisibility(Button.GONE);
                note22Img.setVisibility(Button.GONE);

            }
        });



        animSetXY33.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

                note33Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {


                if(!note33cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu

                }
                note33cliqued[0] = false;


                note33.setVisibility(Button.GONE);
                note33Img.setVisibility(Button.GONE);

            }

        });




        animSetXY44.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                note44Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {


                if(!note44cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu

                }
                note44cliqued[0] = false;

                note44.setVisibility(Button.GONE);
                note44Img.setVisibility(Button.GONE);

            }
        });
        //TROISIEME


        animSetXY111.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

                note111Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {

                if(!note111cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                note111cliqued[0] = false;


                note111.setVisibility(Button.GONE);
                note111Img.setVisibility(Button.GONE);



            }

        });



        animSetXY222.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {


                note222Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {


                if(!note222cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                note222cliqued[0] = false;


                note222.setVisibility(Button.GONE);
                note222Img.setVisibility(Button.GONE);

            }
        });



        animSetXY333.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                note333Img.setAlpha(1.0f);

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {


                if(!note333cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu

                }
                note333cliqued[0] = false;


                note333.setVisibility(Button.GONE);
                note333Img.setVisibility(Button.GONE);

            }

        });




        animSetXY444.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                note444Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {


                if(!note444cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu

                }
                note444cliqued[0] = false;

                note444.setVisibility(Button.GONE);
                note444Img.setVisibility(Button.GONE);

            }
        });


        //LONG

        animSetXYL1.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                long1Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {

                if(longHold1) {

                    longHoldTime1 = System.currentTimeMillis();
                    addLongPoint(longHoldTime1-firstTouch1);                }

                if(!long1cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                long1cliqued[0] = false;
                long1.setVisibility(Button.GONE);
                long1Img.setVisibility(Button.GONE);

            }
        });


        animSetXYL2.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                long2Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {

                if(longHold2) {

                    longHoldTime2 = System.currentTimeMillis();
                    addLongPoint(longHoldTime2-firstTouch2);                }

                if(!long2cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                long2cliqued[0] = false;
                long2.setVisibility(Button.GONE);
                long2Img.setVisibility(Button.GONE);

            }
        });


        animSetXYL3.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {
                long3Img.setAlpha(1.0f);
            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                if(longHold3) {

                    longHoldTime3 = System.currentTimeMillis();
                    addLongPoint(longHoldTime3-firstTouch3);                }

                if(!long3cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                long3cliqued[0] = false;
                long3.setVisibility(Button.GONE);
                long3Img.setVisibility(Button.GONE);

            }
        });


        animSetXYL4.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animator) {

                long4Img.setAlpha(1.0f);

            }

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAnimationEnd(Animator animator) {
                if(longHold4) {

                    longHoldTime4 = System.currentTimeMillis();
                    addLongPoint(longHoldTime4-firstTouch4);                }

                if(!long4cliqued[0]){
                    layoutFail.setBackgroundColor(getColor(R.color.red)); //SI LA NOTE N'EST PAS CLIQUE QUAND L'ANIMATION FINI : elle est passé donc c'est perdu
                }
                long4cliqued[0] = false;
                long4.setVisibility(Button.GONE);
                long4Img.setVisibility(Button.GONE);

            }
        });



        note1.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    if(!note1cliqued[0]) {
                        int intscore = parseInt(score.getText().toString()) + 100;
                        score.setText(String.valueOf(intscore));
                        note1Img.setAlpha(0.3f);
                        note1cliqued[0] = true;

                        vibrator.vibrate(40); //VIBRATE
                    }

                }
                return false;
            }
        });


        note2.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    if(!note2cliqued[0]) {
                        int intscore = parseInt(score.getText().toString()) + 100;
                        score.setText(String.valueOf(intscore));
                        note2Img.setAlpha(0.3f);


                        note2cliqued[0] = true;

                        vibrator.vibrate(40); //VIBRATE
                    }

                }
                return false;
            }
        });

        note3.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    if(!note3cliqued[0]) {
                        int intscore = parseInt(score.getText().toString()) + 100;
                        score.setText(String.valueOf(intscore));
                        note3Img.setAlpha(0.3f);

                        note3cliqued[0] = true;

                        vibrator.vibrate(40); //VIBRATE
                    }

                }
                return false;
            }
        });

        note4.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    if(!note4cliqued[0]) {
                        int intscore = parseInt(score.getText().toString()) + 100;
                        score.setText(String.valueOf(intscore));
                        note4Img.setAlpha(0.3f);

                        note4cliqued[0] = true;

                        vibrator.vibrate(40); //VIBRATE
                    }


                }
                return false;
            }
        });

        //SECOND

        note11.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    if(!note11cliqued[0]) {
                        int intscore = parseInt(score.getText().toString()) + 100;
                        score.setText(String.valueOf(intscore));
                        note11Img.setAlpha(0.3f);
                        note11cliqued[0] = true;

                        vibrator.vibrate(40); //VIBRATE
                    }

                }
                return false;
            }
        });

        note22.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    if(!note22cliqued[0]) {
                        int intscore = parseInt(score.getText().toString()) + 100;
                        score.setText(String.valueOf(intscore));
                        note22Img.setAlpha(0.3f);

                        note22cliqued[0] = true;

                        vibrator.vibrate(40); //VIBRATE
                    }
                }
                return false;
            }
        });

        note33.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    if(!note33cliqued[0]) {
                        int intscore = parseInt(score.getText().toString()) + 100;
                        score.setText(String.valueOf(intscore));
                        note33Img.setAlpha(0.3f);

                        note33cliqued[0] = true;

                        vibrator.vibrate(40); //VIBRATE
                    }


                }
                return false;
            }
        });

        note44.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    if(!note44cliqued[0]) {
                        int intscore = parseInt(score.getText().toString()) + 100;
                        score.setText(String.valueOf(intscore));
                        note44Img.setAlpha(0.3f);

                        note44cliqued[0] = true;

                        vibrator.vibrate(40); //VIBRATE
                    }


                }
                return false;
            }
        });

        //TROISIEME

        note111.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    if(!note111cliqued[0]) {
                        int intscore = parseInt(score.getText().toString()) + 100;
                        score.setText(String.valueOf(intscore));
                        note111Img.setAlpha(0.3f);

                        note111cliqued[0] = true;

                        vibrator.vibrate(40); //VIBRATE
                    }


                }
                return false;
            }
        });

        note222.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    if(!note222cliqued[0]) {
                        int intscore = parseInt(score.getText().toString()) + 100;
                        score.setText(String.valueOf(intscore));
                        note222Img.setAlpha(0.3f);
                        note222cliqued[0] = true;

                        vibrator.vibrate(40); //VIBRATE
                    }


                }
                return false;
            }
        });

        note333.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    if(!note333cliqued[0]) {
                        int intscore = parseInt(score.getText().toString()) + 100;
                        score.setText(String.valueOf(intscore));
                        note333Img.setAlpha(0.3f);

                        note333cliqued[0] = true;

                        vibrator.vibrate(40); //VIBRATE
                    }


                }
                return false;
            }
        });

        note444.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){

                    if(!note444cliqued[0]) {
                        int intscore = parseInt(score.getText().toString()) + 100;
                        score.setText(String.valueOf(intscore));
                        note444Img.setAlpha(0.3f);

                        note444cliqued[0] = true;

                        vibrator.vibrate(40); //VIBRATE
                    }


                }
                return false;
            }
        });


        //LONG

        long1.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                long1Img.setAlpha(0.3f);;
                long1cliqued[0] = true;


                if (event.getAction()==MotionEvent.ACTION_DOWN) {
                    longHold1=true;
                    firstTouch1 = System.currentTimeMillis();


                } else if (event.getAction()==MotionEvent.ACTION_UP) {

                    longHold1 = false;
                    if(animSetXYL1.isStarted()){
                        longHoldTime1 = System.currentTimeMillis();
                        addLongPoint(longHoldTime1-firstTouch1);
                    }
                }
                return false;
            }
        });

        long2.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                long2Img.setAlpha(0.3f);
                long2cliqued[0] = true;


                if (event.getAction()==MotionEvent.ACTION_DOWN) {
                    longHold2=true;
                    firstTouch2 = System.currentTimeMillis();


                } else if (event.getAction()==MotionEvent.ACTION_UP) {

                    longHold2 = false;
                    if(animSetXYL2.isStarted()){
                        longHoldTime2= System.currentTimeMillis();
                        addLongPoint(longHoldTime2-firstTouch2);                    }
                }
                return false;
            }
        });

        long3.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                long3Img.setAlpha(0.3f);;
                long3cliqued[0] = true;


                if (event.getAction()==MotionEvent.ACTION_DOWN) {
                    longHold3=true;
                    firstTouch3 = System.currentTimeMillis();


                } else if (event.getAction()==MotionEvent.ACTION_UP) {

                    longHold3 = false;
                    if(animSetXYL3.isStarted()){
                        longHoldTime3= System.currentTimeMillis();
                        addLongPoint(longHoldTime3-firstTouch3);                    }
                }
                return false;
            }
        });

        long4.setOnTouchListener(new View.OnTouchListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                long4Img.setAlpha(0.3f);
                long4cliqued[0] = true;


                if (event.getAction()==MotionEvent.ACTION_DOWN) {
                    longHold4=true;
                    firstTouch4 = System.currentTimeMillis();


                } else if (event.getAction()==MotionEvent.ACTION_UP) {

                    longHold4 = false;
                    if(animSetXYL4.isStarted()){
                        longHoldTime4= System.currentTimeMillis();
                        addLongPoint(longHoldTime4-firstTouch4);
                    }
                }
                return false;
            }
        });



        /*if(animSetXYL1.isStarted()) {

                    score.setText(String.valueOf(parseInt(score.getText().toString()) + 2));

                }*/





        layoutFail.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

                if(start[0]) {
                    layoutFail.setBackgroundColor(getColor(R.color.red));
                }
            }
        });





        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                start[0] = true;
                startBtn.setVisibility(Button.GONE);
                //VITESSE

                animSetXY1.setDuration(speedNote);
                animSetXY2.setDuration(speedNote);
                animSetXY3.setDuration(speedNote);
                animSetXY4.setDuration(speedNote);

                animSetXY11.setDuration(speedNote);
                animSetXY22.setDuration(speedNote);
                animSetXY33.setDuration(speedNote);
                animSetXY44.setDuration(speedNote);

                animSetXY111.setDuration(speedNote);
                animSetXY222.setDuration(speedNote);
                animSetXY333.setDuration(speedNote);
                animSetXY444.setDuration(speedNote);

                animSetXYL1.setDuration(speedLong);
                animSetXYL2.setDuration(speedLong);
                animSetXYL3.setDuration(speedLong);
                animSetXYL4.setDuration(speedLong);



                game(); //LANCEMENT
            }
        });



    }



    @Override
    protected void onPause() {

        super.onPause();
        if (snk.isPlaying()) snk.stop();

    }





    void addLongPoint(double seconds){
        double dbscore = parseInt(score.getText().toString())+(seconds/5);
        int intscore = (int) dbscore;
        score.setText(String.valueOf(intscore));
    }




    public void game(){
        snk.start();


        new CountDownTimer((long)(3200/multiplier), (long)(1000/multiplier)) {

            @Override
            public void onTick(long millisUntilFinished) {
                // do something after 1s
            }

            @Override
            public void onFinish() {


                new CountDownTimer((long)(10400/multiplier), (long)(400/multiplier)) {

                    @Override
                    public void onTick(long millisUntilFinished) {

                        fall();

                    }

                    @Override
                    public void onFinish() {


                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            public void run() {

                                mainLayout2.setBackgroundResource(R.drawable.degrad_yellow_pink);
                                mainLayout2.startAnimation(transition);
                                mainLayout.setBackgroundResource(R.drawable.degrad_yellow_pink);


                                new CountDownTimer((long)(22700/multiplier), (long)(400/multiplier)) {

                                    @Override
                                    public void onTick(long millisUntilFinished) {

                                        fall();
                                    }

                                    @Override
                                    public void onFinish() {


                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            public void run() {
                                        new CountDownTimer((long)(3100/multiplier), (long)(270/multiplier)) {

                                            @Override
                                            public void onTick(long millisUntilFinished) {

                                                fall();
                                            }

                                            @Override
                                            public void onFinish() {

                                                Handler handler = new Handler();
                                                handler.postDelayed(new Runnable() {
                                                    public void run() {


                                                        Handler handler = new Handler(); //POUR l'animation
                                                        handler.postDelayed(new Runnable() {
                                                            public void run() {
                                                        mainLayout2.setBackgroundResource(R.drawable.degrad_red);
                                                        mainLayout2.startAnimation(transition);
                                                        mainLayout.setBackgroundResource(R.drawable.degrad_red);
                                                            }
                                                        }, (long)(5300/multiplier));



                                                        new CountDownTimer((long)(46000/multiplier), (long)(400/multiplier)) {

                                                            @Override
                                                            public void onTick(long millisUntilFinished) {
                                                                fall();
                                                            }

                                                            @Override
                                                            public void onFinish() { // RECOMMENCER PLUS RAPIDEMENT

                                                                Handler handler = new Handler();
                                                                handler.postDelayed(new Runnable() {
                                                                    @RequiresApi(api = Build.VERSION_CODES.M)
                                                                    public void run() {

                                                                        multiplier = multiplier +(0.05f);
                                                                        snk.setPlaybackParams(snk.getPlaybackParams().setSpeed(multiplier));

                                                                        speedNote=(int)(speedNote/multiplier);
                                                                        speedLong=(int)(speedLong/multiplier);

                                                                        animSetXY1.setDuration(speedNote);
                                                                        animSetXY2.setDuration(speedNote);
                                                                        animSetXY3.setDuration(speedNote);
                                                                        animSetXY4.setDuration(speedNote);

                                                                        animSetXY11.setDuration(speedNote);
                                                                        animSetXY22.setDuration(speedNote);
                                                                        animSetXY33.setDuration(speedNote);
                                                                        animSetXY44.setDuration(speedNote);

                                                                        animSetXY111.setDuration(speedNote);
                                                                        animSetXY222.setDuration(speedNote);
                                                                        animSetXY333.setDuration(speedNote);
                                                                        animSetXY444.setDuration(speedNote);

                                                                        animSetXYL1.setDuration(speedLong);
                                                                        animSetXYL2.setDuration(speedLong);
                                                                        animSetXYL3.setDuration(speedLong);
                                                                        animSetXYL4.setDuration(speedLong);

                                                                        indice=0;

                                                                        mainLayout2.setBackgroundResource(R.drawable.degrad_pink_blue);
                                                                        mainLayout2.startAnimation(transition);
                                                                        mainLayout.setBackgroundResource(R.drawable.degrad_pink_blue);

                                                                        game();


                                                                    }


                                                                }, (long)(5000));

                                                            }

                                                        }.start();


                                                    }
                                                }, (long)(200/multiplier));

                                            }

                                        }.start();

                                            }
                                        }, (long)(300/multiplier));
                                        //

                                    }

                                }.start();


                            }
                        }, (long)(2000/multiplier));


                    }

                 }.start();

            }

        }.start();




    }


    void fall(){
        if(tab[indice]==1){
            if(!animSetXY1.isStarted()) {
                note1Img.setVisibility(Button.VISIBLE);
                note1.setVisibility(Button.VISIBLE);
                animSetXY1.start();
            }
            else {
                if (!animSetXY11.isStarted()) {
                    note11Img.setVisibility(Button.VISIBLE);
                    note11.setVisibility(Button.VISIBLE);
                    animSetXY11.start();
                }
                else{
                    note111Img.setVisibility(Button.VISIBLE);
                    note111.setVisibility(Button.VISIBLE);
                    animSetXY111.start();
                }
            }
        }

        else if(tab[indice]==2){
            if(!animSetXY2.isStarted()) {
                note2Img.setVisibility(Button.VISIBLE);
                note2.setVisibility(Button.VISIBLE);
                animSetXY2.start();


            }
            else{
                if(!animSetXY22.isStarted()) {
                    note22Img.setVisibility(Button.VISIBLE);
                    note22.setVisibility(Button.VISIBLE);
                    animSetXY22.start();
                }
                else{
                    note222Img.setVisibility(Button.VISIBLE);
                    note222.setVisibility(Button.VISIBLE);
                    animSetXY222.start();
                }

            }
        }

        else if(tab[indice]==3){
            if(!animSetXY3.isStarted()) {
                note3Img.setVisibility(Button.VISIBLE);
                note3.setVisibility(Button.VISIBLE);
                animSetXY3.start();
            }
            else {
                if (!animSetXY33.isStarted()) {
                    note33Img.setVisibility(Button.VISIBLE);
                    note33.setVisibility(Button.VISIBLE);
                    animSetXY33.start();
                }
                else{
                    note333Img.setVisibility(Button.VISIBLE);
                    note333.setVisibility(Button.VISIBLE);
                    animSetXY333.start();
                }
            }
        }

        else if(tab[indice]==4){
            if(!animSetXY4.isStarted()) {
                note4Img.setVisibility(Button.VISIBLE);
                note4.setVisibility(Button.VISIBLE);
                animSetXY4.start();
            }
            else {
                if (!animSetXY44.isStarted()) {
                    note44Img.setVisibility(Button.VISIBLE);
                    note44.setVisibility(Button.VISIBLE);
                    animSetXY44.start();
                }
                else{
                    note444Img.setVisibility(Button.VISIBLE);
                    note444.setVisibility(Button.VISIBLE);
                    animSetXY444.start();
                }
            }
        }


        else if(tab[indice]==12){

            if(!animSetXY1.isStarted()) {
                note1Img.setVisibility(Button.VISIBLE);
                note1.setVisibility(Button.VISIBLE);
                animSetXY1.start();
            }
            else {
                if (!animSetXY11.isStarted()) {
                    note11Img.setVisibility(Button.VISIBLE);
                    note11.setVisibility(Button.VISIBLE);
                    animSetXY11.start();
                }
                else{
                    note111Img.setVisibility(Button.VISIBLE);
                    note111.setVisibility(Button.VISIBLE);
                    animSetXY111.start();
                }
            }

            if(!animSetXY2.isStarted()) {
                note2Img.setVisibility(Button.VISIBLE);
                note2.setVisibility(Button.VISIBLE);
                animSetXY2.start();

            }
            else{
                if(!animSetXY22.isStarted()) {
                    note22Img.setVisibility(Button.VISIBLE);
                    note22.setVisibility(Button.VISIBLE);
                    animSetXY22.start();
                }
                else{
                    note222Img.setVisibility(Button.VISIBLE);
                    note222.setVisibility(Button.VISIBLE);
                    animSetXY222.start();
                }

            }
        }



        else if(tab[indice]==13) {

            if (!animSetXY1.isStarted()) {
                note1Img.setVisibility(Button.VISIBLE);
                note1.setVisibility(Button.VISIBLE);
                animSetXY1.start();
            } else {
                if (!animSetXY11.isStarted()) {
                    note11Img.setVisibility(Button.VISIBLE);
                    note11.setVisibility(Button.VISIBLE);
                    animSetXY11.start();
                } else {
                    note111Img.setVisibility(Button.VISIBLE);
                    note111.setVisibility(Button.VISIBLE);
                    animSetXY111.start();
                }
            }
            if(!animSetXY3.isStarted()) {
                note3Img.setVisibility(Button.VISIBLE);
                note3.setVisibility(Button.VISIBLE);
                animSetXY3.start();
            }
            else {
                if (!animSetXY33.isStarted()) {
                    note33Img.setVisibility(Button.VISIBLE);
                    note33.setVisibility(Button.VISIBLE);
                    animSetXY33.start();
                }
                else{
                    note333Img.setVisibility(Button.VISIBLE);
                    note333.setVisibility(Button.VISIBLE);
                    animSetXY333.start();
                }
            }

        }

        else if(tab[indice]==14) {

            if (!animSetXY1.isStarted()) {
                note1Img.setVisibility(Button.VISIBLE);
                note1.setVisibility(Button.VISIBLE);
                animSetXY1.start();
            } else {
                if (!animSetXY11.isStarted()) {
                    note11Img.setVisibility(Button.VISIBLE);
                    note11.setVisibility(Button.VISIBLE);
                    animSetXY11.start();
                } else {
                    note111Img.setVisibility(Button.VISIBLE);
                    note111.setVisibility(Button.VISIBLE);
                    animSetXY111.start();
                }
            }

            if(!animSetXY4.isStarted()) {
                note4Img.setVisibility(Button.VISIBLE);
                note4.setVisibility(Button.VISIBLE);
                animSetXY4.start();
            }
            else {
                if (!animSetXY44.isStarted()) {
                    note44Img.setVisibility(Button.VISIBLE);
                    note44.setVisibility(Button.VISIBLE);
                    animSetXY44.start();
                }
                else{
                    note444Img.setVisibility(Button.VISIBLE);
                    note444.setVisibility(Button.VISIBLE);
                    animSetXY444.start();
                }
            }

        }


        else if(tab[indice]==23){
            if(!animSetXY2.isStarted()) {
                note2Img.setVisibility(Button.VISIBLE);
                note2.setVisibility(Button.VISIBLE);
                animSetXY2.start();

            }
            else{
                if(!animSetXY22.isStarted()) {
                    note22Img.setVisibility(Button.VISIBLE);
                    note22.setVisibility(Button.VISIBLE);
                    animSetXY22.start();
                }
                else{
                    note222Img.setVisibility(Button.VISIBLE);
                    note222.setVisibility(Button.VISIBLE);
                    animSetXY222.start();
                }

            }

            if(!animSetXY3.isStarted()) {
                note3Img.setVisibility(Button.VISIBLE);
                note3.setVisibility(Button.VISIBLE);
                animSetXY3.start();
            }
            else {
                if (!animSetXY33.isStarted()) {
                    note33Img.setVisibility(Button.VISIBLE);
                    note33.setVisibility(Button.VISIBLE);
                    animSetXY33.start();
                }
                else{
                    note333Img.setVisibility(Button.VISIBLE);
                    note333.setVisibility(Button.VISIBLE);
                    animSetXY333.start();
                }
            }
        }

        else if(tab[indice]==24) {
            if (!animSetXY2.isStarted()) {
                note2Img.setVisibility(Button.VISIBLE);
                note2.setVisibility(Button.VISIBLE);
                animSetXY2.start();

            } else {
                if (!animSetXY22.isStarted()) {
                    note22Img.setVisibility(Button.VISIBLE);
                    note22.setVisibility(Button.VISIBLE);
                    animSetXY22.start();
                } else {
                    note222Img.setVisibility(Button.VISIBLE);
                    note222.setVisibility(Button.VISIBLE);
                    animSetXY222.start();
                }

            }

            if(!animSetXY4.isStarted()) {
                note4Img.setVisibility(Button.VISIBLE);
                note4.setVisibility(Button.VISIBLE);
                animSetXY4.start();
            }
            else {
                if (!animSetXY44.isStarted()) {
                    note44Img.setVisibility(Button.VISIBLE);
                    note44.setVisibility(Button.VISIBLE);
                    animSetXY44.start();
                }
                else{
                    note444Img.setVisibility(Button.VISIBLE);
                    note444.setVisibility(Button.VISIBLE);
                    animSetXY444.start();
                }
            }

        }

        else if(tab[indice]==34){
            if(!animSetXY3.isStarted()) {
                note3Img.setVisibility(Button.VISIBLE);
                note3.setVisibility(Button.VISIBLE);
                animSetXY3.start();
            }
            else {
                if (!animSetXY33.isStarted()) {
                    note33Img.setVisibility(Button.VISIBLE);
                    note33.setVisibility(Button.VISIBLE);
                    animSetXY33.start();
                }
                else{
                    note333Img.setVisibility(Button.VISIBLE);
                    note333.setVisibility(Button.VISIBLE);
                    animSetXY333.start();
                }
            }
            if(!animSetXY4.isStarted()) {
                note4Img.setVisibility(Button.VISIBLE);
                note4.setVisibility(Button.VISIBLE);
                animSetXY4.start();
            }
            else {
                if (!animSetXY44.isStarted()) {
                    note44Img.setVisibility(Button.VISIBLE);
                    note44.setVisibility(Button.VISIBLE);
                    animSetXY44.start();
                }
                else{
                    note444Img.setVisibility(Button.VISIBLE);
                    note444.setVisibility(Button.VISIBLE);
                    animSetXY444.start();
                }
            }
        }

        else if(tab[indice]==123){

            if(!animSetXY1.isStarted()) {
                note1Img.setVisibility(Button.VISIBLE);
                note1.setVisibility(Button.VISIBLE);
                animSetXY1.start();
            }
            else {
                if (!animSetXY11.isStarted()) {
                    note11Img.setVisibility(Button.VISIBLE);
                    note11.setVisibility(Button.VISIBLE);
                    animSetXY11.start();
                }
                else{
                    note111Img.setVisibility(Button.VISIBLE);
                    note111.setVisibility(Button.VISIBLE);
                    animSetXY111.start();
                }
            }

            if(!animSetXY2.isStarted()) {
                note2Img.setVisibility(Button.VISIBLE);
                note2.setVisibility(Button.VISIBLE);
                animSetXY2.start();

            }
            else{
                if(!animSetXY22.isStarted()) {
                    note22Img.setVisibility(Button.VISIBLE);
                    note22.setVisibility(Button.VISIBLE);
                    animSetXY22.start();
                }
                else{
                    note222Img.setVisibility(Button.VISIBLE);
                    note222.setVisibility(Button.VISIBLE);
                    animSetXY222.start();
                }

            }
            if(!animSetXY3.isStarted()) {
                note3Img.setVisibility(Button.VISIBLE);
                note3.setVisibility(Button.VISIBLE);
                animSetXY3.start();
            }
            else {
                if (!animSetXY33.isStarted()) {
                    note33Img.setVisibility(Button.VISIBLE);
                    note33.setVisibility(Button.VISIBLE);
                    animSetXY33.start();
                }
                else{
                    note333Img.setVisibility(Button.VISIBLE);
                    note333.setVisibility(Button.VISIBLE);
                    animSetXY333.start();
                }
            }
        }

        else if(tab[indice]==124) {

            if (!animSetXY1.isStarted()) {
                note1Img.setVisibility(Button.VISIBLE);
                note1.setVisibility(Button.VISIBLE);
                animSetXY1.start();
            } else {
                if (!animSetXY11.isStarted()) {
                    note11Img.setVisibility(Button.VISIBLE);
                    note11.setVisibility(Button.VISIBLE);
                    animSetXY11.start();
                } else {
                    note111Img.setVisibility(Button.VISIBLE);
                    note111.setVisibility(Button.VISIBLE);
                    animSetXY111.start();
                }
            }

            if (!animSetXY2.isStarted()) {
                note2Img.setVisibility(Button.VISIBLE);
                note2.setVisibility(Button.VISIBLE);
                animSetXY2.start();

            } else {
                if (!animSetXY22.isStarted()) {
                    note22Img.setVisibility(Button.VISIBLE);
                    note22.setVisibility(Button.VISIBLE);
                    animSetXY22.start();
                } else {
                    note222Img.setVisibility(Button.VISIBLE);
                    note222.setVisibility(Button.VISIBLE);
                    animSetXY222.start();
                }

            }
            if(!animSetXY4.isStarted()) {
                note4Img.setVisibility(Button.VISIBLE);
                note4.setVisibility(Button.VISIBLE);
                animSetXY4.start();
            }
            else {
                if (!animSetXY44.isStarted()) {
                    note44Img.setVisibility(Button.VISIBLE);
                    note44.setVisibility(Button.VISIBLE);
                    animSetXY44.start();
                }
                else{
                    note444Img.setVisibility(Button.VISIBLE);
                    note444.setVisibility(Button.VISIBLE);
                    animSetXY444.start();
                }
            }
        }

        else if(tab[indice]==134) {

            if (!animSetXY1.isStarted()) {
                note1Img.setVisibility(Button.VISIBLE);
                note1.setVisibility(Button.VISIBLE);
                animSetXY1.start();
            } else {
                if (!animSetXY11.isStarted()) {
                    note11Img.setVisibility(Button.VISIBLE);
                    note11.setVisibility(Button.VISIBLE);
                    animSetXY11.start();
                } else {
                    note111Img.setVisibility(Button.VISIBLE);
                    note111.setVisibility(Button.VISIBLE);
                    animSetXY111.start();
                }
            }
            if(!animSetXY3.isStarted()) {
                note3Img.setVisibility(Button.VISIBLE);
                note3.setVisibility(Button.VISIBLE);
                animSetXY3.start();
            }
            else {
                if (!animSetXY33.isStarted()) {
                    note33Img.setVisibility(Button.VISIBLE);
                    note33.setVisibility(Button.VISIBLE);
                    animSetXY33.start();
                }
                else{
                    note333Img.setVisibility(Button.VISIBLE);
                    note333.setVisibility(Button.VISIBLE);
                    animSetXY333.start();
                }
            }
            if(!animSetXY4.isStarted()) {
                note4Img.setVisibility(Button.VISIBLE);
                note4.setVisibility(Button.VISIBLE);
                animSetXY4.start();
            }
            else {
                if (!animSetXY44.isStarted()) {
                    note44Img.setVisibility(Button.VISIBLE);
                    note44.setVisibility(Button.VISIBLE);
                    animSetXY44.start();
                }
                else{
                    note444Img.setVisibility(Button.VISIBLE);
                    note444.setVisibility(Button.VISIBLE);
                    animSetXY444.start();
                }
            }

        }

        else if(tab[indice]==234){
            if(!animSetXY2.isStarted()) {
                note2Img.setVisibility(Button.VISIBLE);
                note2.setVisibility(Button.VISIBLE);
                animSetXY2.start();

            }
            else{
                if(!animSetXY22.isStarted()) {
                    note22Img.setVisibility(Button.VISIBLE);
                    note22.setVisibility(Button.VISIBLE);
                    animSetXY22.start();
                }
                else{
                    note222Img.setVisibility(Button.VISIBLE);
                    note222.setVisibility(Button.VISIBLE);
                    animSetXY222.start();
                }

            }

            if(!animSetXY3.isStarted()) {
                note3Img.setVisibility(Button.VISIBLE);
                note3.setVisibility(Button.VISIBLE);
                animSetXY3.start();
            }
            else {
                if (!animSetXY33.isStarted()) {
                    note33Img.setVisibility(Button.VISIBLE);
                    note33.setVisibility(Button.VISIBLE);
                    animSetXY33.start();
                }
                else{
                    note333Img.setVisibility(Button.VISIBLE);
                    note333.setVisibility(Button.VISIBLE);
                    animSetXY333.start();
                }
            }
            if(!animSetXY4.isStarted()) {
                note4Img.setVisibility(Button.VISIBLE);
                note4.setVisibility(Button.VISIBLE);
                animSetXY4.start();
            }
            else {
                if (!animSetXY44.isStarted()) {
                    note44Img.setVisibility(Button.VISIBLE);
                    note44.setVisibility(Button.VISIBLE);
                    animSetXY44.start();
                }
                else{
                    note444Img.setVisibility(Button.VISIBLE);
                    note444.setVisibility(Button.VISIBLE);
                    animSetXY444.start();
                }
            }
        }

        else if(tab[indice]==1234){

            if(!animSetXY1.isStarted()) {
                note1Img.setVisibility(Button.VISIBLE);
                note1.setVisibility(Button.VISIBLE);
                animSetXY1.start();
            }
            else {
                if (!animSetXY11.isStarted()) {
                    note11Img.setVisibility(Button.VISIBLE);
                    note11.setVisibility(Button.VISIBLE);
                    animSetXY11.start();
                }
                else{
                    note111Img.setVisibility(Button.VISIBLE);
                    note111.setVisibility(Button.VISIBLE);
                    animSetXY111.start();
                }
            }

            if(!animSetXY2.isStarted()) {
                note2Img.setVisibility(Button.VISIBLE);
                note2.setVisibility(Button.VISIBLE);
                animSetXY2.start();

            }
            else{
                if(!animSetXY22.isStarted()) {
                    note22Img.setVisibility(Button.VISIBLE);
                    note22.setVisibility(Button.VISIBLE);
                    animSetXY22.start();
                }
                else{
                    note222Img.setVisibility(Button.VISIBLE);
                    note222.setVisibility(Button.VISIBLE);
                    animSetXY222.start();
                }

            }
            if(!animSetXY3.isStarted()) {
                note3Img.setVisibility(Button.VISIBLE);
                note3.setVisibility(Button.VISIBLE);
                animSetXY3.start();
            }
            else {
                if (!animSetXY33.isStarted()) {
                    note33Img.setVisibility(Button.VISIBLE);
                    note33.setVisibility(Button.VISIBLE);
                    animSetXY33.start();
                }
                else{
                    note333Img.setVisibility(Button.VISIBLE);
                    note333.setVisibility(Button.VISIBLE);
                    animSetXY333.start();
                }
            }
            if(!animSetXY4.isStarted()) {
                note4Img.setVisibility(Button.VISIBLE);
                note4.setVisibility(Button.VISIBLE);
                animSetXY4.start();
            }
            else {
                if (!animSetXY44.isStarted()) {
                    note44Img.setVisibility(Button.VISIBLE);
                    note44.setVisibility(Button.VISIBLE);
                    animSetXY44.start();
                }
                else{
                    note444Img.setVisibility(Button.VISIBLE);
                    note444.setVisibility(Button.VISIBLE);
                    animSetXY444.start();
                }
            }
        }


        else if(tab[indice]==11) {
            if (!animSetXYL1.isStarted()) {
                long1Img.setVisibility(Button.VISIBLE);
                long1.setVisibility(Button.VISIBLE);
                animSetXYL1.start();
            }
        }
        else if(tab[indice]==22) {
            if (!animSetXYL2.isStarted()) {
                long2Img.setVisibility(Button.VISIBLE);
                long2.setVisibility(Button.VISIBLE);
                animSetXYL2.start();
            }
        }
        else if(tab[indice]==33) {
            if (!animSetXYL3.isStarted()) {
                long3Img.setVisibility(Button.VISIBLE);
                long3.setVisibility(Button.VISIBLE);
                animSetXYL3.start();
            }
        }
        else if(tab[indice]==44) {
            if (!animSetXYL4.isStarted()) {
                long4Img.setVisibility(Button.VISIBLE);
                long4.setVisibility(Button.VISIBLE);
                animSetXYL4.start();
            }
        }

        indice = indice + 1;
        if(indice == tab.length){indice = 0;}
    }

}


















































/*
new CountDownTimer(5000, 5000) {

            @Override
            public void onTick(long millisUntilFinished) {
                // do something after 1s
            }

            @Override
            public void onFinish() {


            }

        }.start();



        ANIMATOR TOGETHER

        ObjectAnimator animX = ObjectAnimator.ofFloat(myView, "x", 50f);
ObjectAnimator animY = ObjectAnimator.ofFloat(myView, "y", 100f);
AnimatorSet animSetXY = new AnimatorSet();
animSetXY.playTogether(animX, animY);
animSetXY.start();



PLAN : MEME CHOSE POUR LONG 2 3 4  , ajouter points en fonction des secondes, trouver animation de maintiens
 */
